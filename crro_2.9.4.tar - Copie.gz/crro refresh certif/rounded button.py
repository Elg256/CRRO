import tkinter as tk
from tkinter.ttk import *
from tkinter import *
from tkinter import ttk, filedialog, messagebox
import hashlib
import base64
import pyperclip
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
from cryptography.fernet import Fernet
import sympy
import threading
import os
import psutil
import time

from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from crypto_ecc.ecies_with_encrypt import generate_private_key, encrypt_message, decrypt_message, generate_public_key

from crypto_ecc.ecdsa import ecdsa_signature, verification_signature

key_management_window1 = None
key_management_window = None
key_access_window = None
certificats_fenetre = None

cle = 1
key1 = None
cle_visible = 2
cle_visible2 = 2
type = 1
sign = 2
chiffrage = 2
rsa = 100

evenement_changement_champ = threading.Event()


def creer_smartcard():
    global key_access_window
    global chiffrage
    if key_access_window is not None:
        key_access_window.deiconify()
        return

    key_access_window1 = tk.Toplevel(fenetre)
    key_access_window1.title("Access to the key pair")


    new_window_width = 350
    new_window_height = 125

    x = fenetre.winfo_x() + (fenetre.winfo_width() - new_window_width) // 2
    y = fenetre.winfo_y() + (fenetre.winfo_height() - new_window_height) // 2

    key_access_window1.geometry(f"{new_window_width}x{new_window_height}+{x}+{y}")

    def on_key_access_window_close():
        global key_access_window
        key_access_window1.destroy()
        key_access_window = None

    key_access_window1.protocol("WM_DELETE_WINDOW", on_key_access_window_close)

    label_nom = ttk.Label(key_access_window1, text="Name:", font=("Helvetica", 12))
    label_nom.grid(padx=120)
    champ_nom = ttk.Entry(key_access_window1, width=50)
    champ_nom.grid()

    label_password = ttk.Label(key_access_window1, text="Password:", font=("Helvetica", 12))
    label_password.grid(padx=120)
    champ_password = ttk.Entry(key_access_window1, width=50, show="*")
    champ_password.grid()

    def access_key_pair3(event=None):
        global chiffrage
        if chiffrage == True:

            password = champ_password.get().strip()

            # Conversion du mot de passe en une clé de 32 octets
            key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)

            # Encodage de la clé en base64
            encoded_key = base64.urlsafe_b64encode(key)

            # Création de l'objet Fernet avec la clé encodée
            cipher_suite = Fernet(encoded_key)

            with open("gestion_avancé.txt", "r") as file:
                stored_key_pair = file.read().strip().split('\n')

                # Décryptage de la paire de clés avec la clé
                decrypted_public_key = cipher_suite.decrypt(stored_key_pair[0].split(': ')[1].encode('utf-8')).decode(
                    'utf-8')
                decrypted_private_key = cipher_suite.decrypt(stored_key_pair[1].split(': ')[1].encode('utf-8')).decode(
                    'utf-8')

                champ_clepriver.delete(0, tk.END)

                champ_clepriver.insert(tk.END, decrypted_private_key)

                messagebox.showinfo("Authorized access", "Access to the key pair authorized.")

            on_key_access_window_close()

        else:
            password = champ_password.get().strip()

            # Hachage du mot de passe avec SHA-256
            password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()

            # Double hachage du hash du mot de passe avec SHA-256
            double_hash = "Nom: " + champ_nom.get().strip()

            print("nom:", double_hash)

            # Lecture du fichier texte pour trouver la paire de clés chiffrées correspondante
            with open("key_pairs.txt", "r") as file:
                lines = file.readlines()
                found = False
                for i in range(0, len(lines), 5):  # Increment range by 5 since each pair occupies 5 lines
                    if lines[i].strip() == double_hash:
                        encrypted_public_key = lines[i + 3].strip().split(": ")[1]
                        encrypted_private_key = lines[i + 4].strip().split(": ")[1]

                        # Déchiffrement des clés avec le mot de passe
                        key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)
                        encoded_key = base64.urlsafe_b64encode(key)
                        cipher_suite = Fernet(encoded_key)

                        public_key = cipher_suite.decrypt(encrypted_public_key.encode('utf-8')).decode('utf-8')
                        private_key = cipher_suite.decrypt(encrypted_private_key.encode('utf-8')).decode('utf-8')

                        champ_clepriver.delete(0, tk.END)

                        champ_clepriver.insert(tk.END, private_key)

                        found = True
                        refresh_sha256()
                        on_key_access_window_close()
                        give_key()
                        break

                if not found:
                    messagebox.showerror("Access denied", "incorrect name.")

            on_key_access_window_close()

    # Associer la touche "Entrée" à la fonction access_key_pair3
    champ_password.bind("<Return>", access_key_pair3)

    # Ajouter le bouton "Accéder" s'il n'est pas déjà présent dans la fenêtre
    bouton_access = ttk.Button(key_access_window1, text="Access", command=access_key_pair3)
    bouton_access.grid()


def give_key():
    def encrypt_file_smartcard():
        global cle_man

        output_path = os.path.join(os.path.expanduser('~'), 'Desktop')

        # Nom du fichier
        file_name = 'private_key.key'

        # Chemin complet du fichier
        output_path = os.path.join(output_path, file_name)

        if os.path.exists(output_path):
            messagebox.showerror("Error", "The output file already exists.")
            return

        def bar_de_chargement():
            root = tk.Toplevel()
            root.title("Chargement")

            # Obtenir les dimensions de l'écran
            screen_width = root.winfo_screenwidth()
            screen_height = root.winfo_screenheight()

            # Calculer les coordonnées pour centrer la fenêtre de chargement
            window_width = 300
            window_height = 100
            x = (screen_width - window_width) // 2
            y = (screen_height - window_height) // 2

            root.geometry(f"{window_width}x{window_height}+{x}+{y}")

            root.grab_set()  # Mettre la fenêtre en premier plan

            progress_bar = ttk.Progressbar(root, orient="horizontal", length=window_width - 20, mode="indeterminate")
            progress_bar.pack(pady=20)
            progress_bar.start()

            def encrypt_and_close():
                global cle_man
                cle_man = champ_cle.get()
                fernet = Fernet(cle_man)
                cle_publique_bytes = champ_clepublique.get().encode()

                cle_priver_bytes = champ_clepriver.get().encode()

                prefixe_public = "Public key: ".encode()
                public_encrypted_data = fernet.encrypt(cle_publique_bytes)
                public_encrypted_data = public_encrypted_data + "\n".encode()
                public_key_and_prefixe = prefixe_public + public_encrypted_data

                private_encrypted_data = fernet.encrypt(cle_priver_bytes)
                prefixe_private = "Private key: ".encode()
                private_key_and_prefixe = prefixe_private + private_encrypted_data

                encrypted_key_with_prefixes = public_key_and_prefixe + private_key_and_prefixe

                with open(output_path, "wb") as encrypted_file:
                    encrypted_file.write(encrypted_key_with_prefixes)

                root.destroy()

                messagebox.showinfo("Smartcard", "Smartcard created successfully.")

            root.protocol('WM_DELETE_WINDOW', root.destroy)  # Disable closing of the Toplevel window

            threading.Thread(target=encrypt_and_close).start()

        bar_de_chargement()

    def generate_key():
        window.attributes('-topmost', True)

        """
        Génère une nouvelle clé AES
        """
        global key4
        global cle_man
        key4 = Fernet.generate_key()
        champ_cle.delete(0, tk.END)
        champ_cle.insert(tk.END, key4)
        cle_man = champ_cle.get()
        return cle_man

    def generate_new_key():
        global key4
        key4 = generate_key()

    def generate_fernet_key_from_password_base64():
        # Convertir le mot de passe en bytes
        password = champ_password.get()
        password = str(password)

        password = password.encode()

        # Utiliser PBKDF2HMAC pour dériver une clé de 32 octets (256 bits)
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b'',
            iterations=100000,
            backend=default_backend()
        )
        key = kdf.derive(password)

        # Encoder la clé en base64
        key_base64 = base64.urlsafe_b64encode(key)
        champ_cle.delete(0, tk.END)
        champ_cle.insert(tk.END, key_base64)
        encrypt_file_smartcard()
        window2.withdraw()

        return key_base64

        bar_de_chargement()

    window2 = tk.Toplevel()

    window2.title("AES encryption program")
    window2.geometry("370x80")

    champ_cle = ttk.Entry(window2, width=55)
    champ_cle.pack_forget()

    password_label = ttk.Label(window2, text="Password :")
    password_label.pack()

    champ_password = ttk.Entry(window2, width=50, show="*")
    champ_password.pack()

    generate_keypassword_button = ttk.Button(window2, text="Create Smartcard",
                                             command=lambda: generate_fernet_key_from_password_base64())
    generate_keypassword_button.pack(pady=7)


def utiliser_smartcard():
    def chercher_fichier_usb(nom_fichier):
        for partition in psutil.disk_partitions():
            if 'removable' in partition.opts or 'usb' in partition.opts:
                chemin_recherche = partition.mountpoint
                for dossier, sous_dossiers, fichiers in os.walk(chemin_recherche):
                    if nom_fichier in fichiers:
                        chemin_complet = os.path.join(dossier, nom_fichier)
                        return chemin_complet
        return None

    nom_fichier_recherche = "private_key.key"

    chemin_trouve = chercher_fichier_usb(nom_fichier_recherche)

    if not chemin_trouve:
        response = messagebox.askyesno("No Smartcard",
                                       "No Samrtcard found, searched manually?. ")
        if response:
            nom_fichier = file_path = filedialog.askopenfilename(title="Select key file")


    else:
        response = messagebox.askyesno("Smartcard detected", "A Smartcard was found, use it? ")
        if response:
            file_path = chemin_trouve
            nom_fichier = chemin_trouve

    with open(nom_fichier, "r") as fichier:
        contenu = fichier.read()  # Vous pouvez utiliser readline() ou readlines() selon vos besoins

    def decrypt_file():

        def generate_fernet_key_from_password_base64_2(Event=None):
            # Convertir le mot de passe en bytes
            password = champ_password.get()
            password = str(password)

            password = password.encode()

            # Utiliser PBKDF2HMAC pour dériver une clé de 32 octets (256 bits)
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=b'',
                iterations=100000,
                backend=default_backend()
            )
            key = kdf.derive(password)

            # Encoder la clé en base64
            key_base64 = base64.urlsafe_b64encode(key)
            key_entry.delete(0, tk.END)
            key_entry.insert(tk.END, key_base64)
            bar_de_chargement()
            return key_base64

        def bar_de_chargement():
            root = tk.Toplevel()
            root.title("Loading")

            # Obtenir les dimensions de l'écran
            screen_width = root.winfo_screenwidth()
            screen_height = root.winfo_screenheight()

            # Calculer les coordonnées pour centrer la fenêtre de chargement
            window_width = 300
            window_height = 100
            x = (screen_width - window_width) // 2
            y = (screen_height - window_height) // 2

            root.geometry(f"{window_width}x{window_height}+{x}+{y}")

            root.grab_set()  # Mettre la fenêtre en premier plan

            progress_bar = ttk.Progressbar(root, orient="horizontal", length=window_width - 20, mode="indeterminate")
            progress_bar.pack(pady=20)
            progress_bar.start()

            def decrypt_and_close():
                user_key = key_entry.get().encode()
                key_entry_window.destroy()
                try:
                    fernet = Fernet(user_key)
                    with open(file_path, "rb") as file:
                        encrypted_data = file.read()

                    decrypted_data = fernet.decrypt(encrypted_data)
                    decrypted_data_utf8 = decrypted_data.decode('utf-8')

                    champ_clepriver.delete(0, tk.END)
                    champ_clepriver.insert(tk.END, decrypted_data_utf8)

                    root.destroy()
                    messagebox.showinfo("Authorized access", "Private key access successful.")
                except Exception as e:
                    root.destroy()
                    messagebox.showerror("Error",
                                         "The code is incorrect or Smartcard defective. Decryption failed.")
                    print(e)

            root.protocol('WM_DELETE_WINDOW', lambda: None)  # Disable closing of the Toplevel window

            threading.Thread(target=decrypt_and_close).start()

        key_entry_window = tk.Toplevel(window)
        key_entry_window.title("Access to the Smartcard")
        key_entry_window.geometry("370x70")


        key_entry = ttk.Entry(key_entry_window, width=50)
        key_entry.pack_forget()
        key_entry.focus()

        password_label = ttk.Label(key_entry_window, text="Password:", font=("Helvetica", 12))
        password_label.pack(padx=120)
        champ_password = ttk.Entry(key_entry_window, width=50, show="*")
        champ_password.pack()
        champ_password.bind("<Return>", generate_fernet_key_from_password_base64_2)

        generate_keypassword_button = ttk.Button(key_entry_window, text="Access",
                                                 command=lambda: generate_fernet_key_from_password_base64_2())

        generate_keypassword_button.pack()
        key_entry_window.attributes('-topmost', True)

    decrypt_file()


def enregistrer_parametres():
    parametres_file = "parametres.txt"

    # Ouvrir le fichier en mode écriture
    with open(parametres_file, "w") as file:
        # Écrire les paramètres dans le fichier
        global type
        file.write(f"Cle: {cle}\n")
        file.write(f"cle_visible: {cle_visible}\n")
        file.write(f"cle_visible2: {cle_visible2}\n")
        file.write(f"type: {type}\n")
        file.write(f"sign: {sign}\n")
        file.write(f"chiffrage: {chiffrage}\n")
        file.write(f"rsa: {rsa}\n")

    fenetre.quit()


viscle = cle_visible

viscle2 = cle_visible2


def generate_aes_key():
    key = os.urandom(32)  # Générer une clé de 256 bits (32 octets)
    backend = default_backend()
    cipher = Cipher(algorithms.AES(key), modes.ECB(), backend=backend)
    encryptor = cipher.encryptor()
    truncated_key = encryptor.update(key) + encryptor.finalize()[:8]  # Tronquer la clé à la longueur appropriée
    return truncated_key


def ouvrir_file():
    global window

    if window is not None and window.winfo_exists():
        window.deiconify()
        return

    def open_file_encryption_window():
        global window2

        if window2 is not None and window2.winfo_exists():
            window2.deiconify()
            return
        window.withdraw()

        def generate_key():
            window.attributes('-topmost', True)

            """
            Génère une nouvelle clé AES
            """
            global key4
            global cle_man
            key4 = Fernet.generate_key()
            champ_cle.delete(0, tk.END)
            champ_cle.insert(tk.END, key4)
            cle_man = champ_cle.get()
            return cle_man

        def generate_new_key():
            global key4
            key4 = generate_key()

        def generate_fernet_key_from_password_base64():
            # Convertir le mot de passe en bytes
            password = champ_password.get()
            password = str(password)

            password = password.encode()

            # Utiliser PBKDF2HMAC pour dériver une clé de 32 octets (256 bits)
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=b'',
                iterations=100000,
                backend=default_backend()
            )
            key = kdf.derive(password)

            # Encoder la clé en base64
            key_base64 = base64.urlsafe_b64encode(key)
            champ_cle.delete(0, tk.END)
            champ_cle.insert(tk.END, key_base64)
            encrypt_file()
            return key_base64

        def encrypt_file():
            global cle_man
            cle_man = champ_cle.get()
            file_path = filedialog.askopenfilename(title="Select file to encrypt")
            if not file_path:
                return
            # Utilisation de os.path.basename() pour récupérer le nom complet du fichier
            nom_complet = os.path.basename(file_path)

            # Concaténation de ".enc" à la fin du nom complet du fichier
            nouveau_nom_complet = nom_complet + ".crro"

            output_path_entry = output_entry.get().strip()
            if output_path_entry:
                output_path = os.path.join(output_path_entry, nouveau_nom_complet)

            else:
                # Construction du chemin de sortie complet avec le nouveau nom de fichier
                output_path = os.path.join(os.path.dirname(__file__), nouveau_nom_complet)

            if os.path.exists(output_path):
                messagebox.showerror("Error", "The output file already exists.")
                return

            def bar_de_chargement():
                root = tk.Toplevel()
                root.title("Loading")

                # Obtenir les dimensions de l'écran
                screen_width = root.winfo_screenwidth()
                screen_height = root.winfo_screenheight()

                # Calculer les coordonnées pour centrer la fenêtre de chargement
                window_width = 300
                window_height = 100
                x = (screen_width - window_width) // 2
                y = (screen_height - window_height) // 2

                root.geometry(f"{window_width}x{window_height}+{x}+{y}")

                root.grab_set()  # Mettre la fenêtre en premier plan

                progress_bar = ttk.Progressbar(root, orient="horizontal", length=window_width - 20,
                                               mode="indeterminate")
                progress_bar.pack(pady=20)
                progress_bar.start()

                def encrypt_and_close():
                    fernet = Fernet(cle_man)

                    with open(file_path, "rb") as file:
                        file_data = file.read()

                    encrypted_data = fernet.encrypt(file_data)
                    with open(output_path, "wb") as encrypted_file:
                        encrypted_file.write(encrypted_data)

                    root.destroy()

                    messagebox.showinfo("Successful encryption", "The file was successfully encrypted.")
                    copy_key = messagebox.askyesno("Copy key",
                                                   "Do you want to copy the key to the clipboard ?\n\nKey : " + cle_man)
                    if copy_key:
                        pyperclip.copy(cle_man)

                root.protocol('WM_DELETE_WINDOW', root.destroy)  # Disable closing of the Toplevel window

                threading.Thread(target=encrypt_and_close).start()

            bar_de_chargement()

        window2 = tk.Toplevel()

        window2.title("AES encryption program")
        window2.geometry("390x220")

        cle_label = ttk.Label(window2, text="AES Key :")
        cle_label.pack()

        champ_cle = ttk.Entry(window2, width=55)
        champ_cle.pack()

        generate_key_button = ttk.Button(window2, text="Generate a random key", command=lambda: generate_new_key())
        generate_key_button.pack(pady=1)

        encrypt_button = ttk.Button(window2, text="Encrypt a file with the AES key", command=encrypt_file)
        encrypt_button.pack(pady=7)

        ou_label = ttk.Label(window2, text="Or")
        ou_label.pack()

        password_label = ttk.Label(window2, text="Password :")
        password_label.pack()

        champ_password = ttk.Entry(window2, width=20)
        champ_password.pack()

        generate_keypassword_button = ttk.Button(window2, text="Encrypt with current password",
                                                 command=lambda: generate_fernet_key_from_password_base64())
        generate_keypassword_button.pack(pady=7)

    # Créer une clé Fernet AES à partir d'un mot de passe et encoder en base64

    def decrypt_file():
        window.attributes('-topmost', True)
        window.withdraw()

        """
        Déchiffre un fichier en demandant la clé AES à l'utilisateur
        """
        file_path = filedialog.askopenfilename(title="Select the file to decrypt")
        if not file_path:
            return

        output_path_entry = output_entry.get().strip()
        if output_path_entry:
            # Utilisation de os.path.splitext() pour obtenir le nom de base du fichier sans son extension
            nom_complet = os.path.basename(file_path)
            nom_sans_extension = os.path.splitext(nom_complet)[0]

            output_path = os.path.join(output_path_entry, nom_sans_extension)
        else:
            output_path = os.path.join(os.path.dirname(__file__),
                                       os.path.splitext(os.path.basename(file_path))[0])

        if os.path.exists(output_path):
            messagebox.showerror("Error", "The output file already exists.")
            return

        def generate_fernet_key_from_password_base64_2():
            # Convertir le mot de passe en bytes
            password = champ_password.get()
            password = str(password)

            password = password.encode()

            # Utiliser PBKDF2HMAC pour dériver une clé de 32 octets (256 bits)
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=b'',
                iterations=100000,
                backend=default_backend()
            )
            key = kdf.derive(password)

            # Encoder la clé en base64
            key_base64 = base64.urlsafe_b64encode(key)
            key_entry.delete(0, tk.END)
            key_entry.insert(tk.END, key_base64)
            bar_de_chargement()
            return key_base64

        def bar_de_chargement():
            root = tk.Toplevel()
            root.title("Loading")

            # Obtenir les dimensions de l'écran
            screen_width = root.winfo_screenwidth()
            screen_height = root.winfo_screenheight()

            # Calculer les coordonnées pour centrer la fenêtre de chargement
            window_width = 300
            window_height = 100
            x = (screen_width - window_width) // 2
            y = (screen_height - window_height) // 2

            root.geometry(f"{window_width}x{window_height}+{x}+{y}")

            root.grab_set()  # Mettre la fenêtre en premier plan

            progress_bar = ttk.Progressbar(root, orient="horizontal", length=window_width - 20, mode="indeterminate")
            progress_bar.pack(pady=20)
            progress_bar.start()

            def decrypt_and_close():
                user_key = key_entry.get().encode()
                key_entry_window.destroy()
                try:
                    fernet = Fernet(user_key)
                    with open(file_path, "rb") as file:
                        encrypted_data = file.read()
                    decrypted_data = fernet.decrypt(encrypted_data)
                    with open(output_path, "wb") as decrypted_file:
                        decrypted_file.write(decrypted_data)
                    root.destroy()
                    messagebox.showinfo("Successful decryption", "The file was successfully decrypted.")
                except Exception:
                    root.destroy()
                    messagebox.showerror("Error", "The supplied key is incorrect. Decryption failed.")

            root.protocol('WM_DELETE_WINDOW', lambda: None)  # Disable closing of the Toplevel window

            threading.Thread(target=decrypt_and_close).start()

        key_entry_window = tk.Toplevel(window)
        key_entry_window.title("Decryption key")
        key_entry_window.geometry("370x200")

        key_label = ttk.Label(key_entry_window, text="Enter AES key for decryption: ")
        key_label.pack()
        key_entry = ttk.Entry(key_entry_window, width=50)
        key_entry.pack()
        key_entry.focus()

        decrypt_button = ttk.Button(key_entry_window, text="Decrypt", command=bar_de_chargement)
        decrypt_button.pack(pady=10)

        password_label1 = ttk.Label(key_entry_window, text="Or")
        password_label1.pack()

        password_label = ttk.Label(key_entry_window, text="Password:")
        password_label.pack()

        champ_password = ttk.Entry(key_entry_window, width=20)
        champ_password.pack()

        generate_keypassword_button = ttk.Button(key_entry_window, text="Decrypt with current password",
                                                 command=lambda: generate_fernet_key_from_password_base64_2())

        generate_keypassword_button.pack(pady=10)
        key_entry_window.attributes('-topmost', True)

    window = tk.Toplevel()

    window.title("AES encryption program")
    window.geometry("300x140")

    key = None

    output_label = ttk.Label(window, text="Encryption/decryption output path :")
    output_label.pack()

    output_entry = ttk.Entry(window, width=30)
    output_entry.insert(0, os.path.join(os.path.expanduser('~'), 'Desktop'))
    output_entry.pack()

    encrypt_button = ttk.Button(window, text="Encrypt a file", command=open_file_encryption_window)
    encrypt_button.pack(pady=8)

    decrypt_button = ttk.Button(window, text="Decrypt a file", command=decrypt_file)
    decrypt_button.pack(pady=8)


window2 = None
window = None

parametres = None


def adressebtc():
    adressebtc = tk.Toplevel(fenetre)

    adressebtc.title("support us")
    label_adressebtc = ttk.Label(adressebtc, text="Bitcoin Address:", font=("Helvetica", 12))
    label_adressebtc.pack()
    champ_adressebtc = ttk.Entry(adressebtc, width=50)
    champ_adressebtc.pack()
    champ_adressebtc.insert(0, "bc1q8j946v6gcnpumdjhdem2hhameh33fe4cy4xpqt")
    champ_adressebtc.pack(pady=10, padx=15)


def ouvrir_parametres2():
    global parametres2

    # Vérifier si la deuxième fenêtre est déjà ouverte
    if parametres2 is not None and parametres2.winfo_exists():
        parametres2.deiconify()
        return
    parametres2 = tk.Toplevel(fenetre)

    parametres2.title("Settings")

    def fenetreferme():
        parametres2.destroy()
        global cle
        global type
        global chiffrage
        chiffrage = 2
        cle = 2
        if type == 3:
            type2.set("AES")
            label_typechiffrage2.config(text=type2.get())
        elif type == 2:
            type2.set("RSA")
            label_typechiffrage2.config(text=type2.get())
        elif type == 1:
            type2.set("AES + RSA")
            label_typechiffrage2.config(text=type2.get())
        elif type == 4:
            type2.set("no encryption")
            label_typechiffrage2.config(text=type2.get())

    def fenetreferme2():
        parametres2.destroy()
        global cle
        global type
        global chiffrage
        chiffrage = 2
        cle = 1
        if type == 3:
            type2.set("AES")
            label_typechiffrage2.config(text=type2.get())
        elif type == 2:
            type2.set("RSA")
            label_typechiffrage2.config(text=type2.get())
        elif type == 1:
            type2.set("AES + RSA")
            label_typechiffrage2.config(text=type2.get())
        elif type == 4:
            type2.set("no encryption")
            label_typechiffrage2.config(text=type2.get())

    def fenetreferme3():
        parametres2.destroy()
        global cle
        global type
        global chiffrage
        chiffrage = 2
        cle = 3
        if type == 3:
            type2.set("AES")
            label_typechiffrage2.config(text=type2.get())
        elif type == 2:
            type2.set("RSA")
            label_typechiffrage2.config(text=type2.get())
        elif type == 1:
            type2.set("AES + RSA")
            label_typechiffrage2.config(text=type2.get())
        elif type == 4:
            type2.set("no encryption")
            label_typechiffrage2.config(text=type2.get())
        elif type == 5:
            type2.set("ECIES")
            label_typechiffrage2.config(text=type2.get())

    def fenetreferme4():
        parametres2.destroy()
        global cle
        global chiffrage
        global sign
        chiffrage = 1
        sign = 2
        cle = 4
        type2.set("Advanced")
        label_typechiffrage2.config(text=type2.get())
        sign2.set("Disable")
        label_typechiffrage2.config(text=sign2.get())

    label_taille = ttk.Label(parametres2, text="RSA Key lenght:", font=("Helvetica", 12))
    label_taille.pack(pady=5)
    bouton_access = ttk.Button(parametres2, text="1024 bits (+ fast)", command=fenetreferme2)
    bouton_access.pack()

    bouton_access = ttk.Button(parametres2, text="2048 bits ", command=fenetreferme)
    bouton_access.pack()

    bouton_access = ttk.Button(parametres2, text="3072 bits (+ safe)", command=fenetreferme3)
    bouton_access.pack()

    if cle == 2:
        label_type_cle = ttk.Label(parametres2, text="Currently in mode : 2048 bits", font=("Helvetica", 12))
        label_type_cle.pack(pady=7)
    elif cle == 1:
        label_type_cle = ttk.Label(parametres2, text="Currently in mode : 1024 bits ", font=("Helvetica", 12))
        label_type_cle.pack(pady=7)

    elif cle == 3:
        label_type_cle = ttk.Label(parametres2, text="Currently in mode : 3072 bits", font=("Helvetica", 12))
        label_type_cle.pack(pady=7)

    elif cle == 4:
        label_type_cle = ttk.Label(parametres2, text="Currently in mode : 4096 bits", font=("Helvetica", 12))
        label_type_cle.pack(pady=7)

    def fermer_parametres():
        parametres.destroy()
        # Enregistrer les paramètres lorsque la fenêtre est fermée


parametres2 = None


def ouvrir_parametres_rsa():
    global para_rsa
    global rsa
    # Vérifier si la deuxième fenêtre est déjà ouverte
    if para_rsa is not None and para_rsa.winfo_exists():
        para_rsa.deiconify()
        return
    para_rsa = tk.Toplevel(fenetre)

    para_rsa.title("Settings")

    def fenetreferme():
        para_rsa.destroy()
        global rsa
        rsa = 3

    def fenetreferme2():
        para_rsa.destroy()
        global rsa
        rsa = 1

    def fenetreferme3():
        para_rsa.destroy()
        global rsa
        rsa = 100

    label_taille = ttk.Label(para_rsa, text=" RSA blocks lenght:", font=("Helvetica", 12))
    label_taille.pack(pady=5)
    bouton_access = ttk.Button(para_rsa, text="1", width=4, command=fenetreferme2)
    bouton_access.pack()

    bouton_access = ttk.Button(para_rsa, text="3", width=4, command=fenetreferme)
    bouton_access.pack()

    bouton_access = ttk.Button(para_rsa, text="100", width=4, command=fenetreferme3)
    bouton_access.pack()

    if rsa == 1:
        label_type_cle = ttk.Label(para_rsa, text="Currently in length : 1", font=("Helvetica", 12))
        label_type_cle.pack(pady=7)
    if rsa == 3:
        label_type_cle = ttk.Label(para_rsa, text="Currently in length : 3", font=("Helvetica", 12))
        label_type_cle.pack(pady=7)
    elif rsa == 100:
        label_type_cle = ttk.Label(para_rsa, text="Currently in length : 100", font=("Helvetica", 12))
        label_type_cle.pack(pady=7)

    def fermer_parametres():
        para_rsa.destroy()
        # Enregistrer les paramètres lorsque la fenêtre est fermée


para_rsa = None


def charger_parametres():
    parametres_file = "parametres.txt"

    # Vérifier si le fichier de paramètres existe
    if os.path.exists(parametres_file):
        # Ouvrir le fichier en mode lecture
        with open(parametres_file, "r") as file:
            # Lire les lignes du fichier
            lignes = file.readlines()

            # Parcourir les lignes et extraire les paramètres
            for ligne in lignes:
                if ligne.startswith("Cle:"):
                    # Extraire la valeur du paramètre Cle
                    cle_value = int(ligne.split(":")[1].strip())
                    # Mettre à jour la variable globale cle
                    global cle
                    cle = cle_value
                elif ligne.startswith("sign:"):
                    # Extraire la valeur du paramètre Signature
                    signature_value = int(ligne.split(":")[1].strip())
                    # Mettre à jour la variable globale signature
                    global sign
                    sign = signature_value
                elif ligne.startswith("cle_visible:"):
                    global cle_visible

                    # Extraire la valeur du paramètre Signature
                    cle_visible_value = int(ligne.split(":")[1].strip())
                    # Mettre à jour la variable globale signature
                    cle_visible = cle_visible_value
                elif ligne.startswith("type:"):
                    # Extraire la valeur du paramètre Signature
                    type_value = int(ligne.split(":")[1].strip())
                    # Mettre à jour la variable globale signature
                    global type
                    type = type_value
                elif ligne.startswith("chiffrage:"):
                    # Extraire la valeur du paramètre Signature
                    chiffrage_value = int(ligne.split(":")[1].strip())
                    # Mettre à jour la variable globale signature
                    global chiffrage
                    chiffrage = chiffrage_value
                elif ligne.startswith("rsa:"):
                    # Extraire la valeur du paramètre Signature
                    rsa_value = int(ligne.split(":")[1].strip())
                    # Mettre à jour la variable globale signature
                    global rsa
                    rsa = rsa_value
                elif ligne.startswith("cle_visible2:"):
                    # Extraire la valeur du paramètre Signature
                    type_value = int(ligne.split(":")[1].strip())
                    # Mettre à jour la variable globale signature
                    global cle_visible2
                    cle_visible2 = type_value


def ajouter_cle(entry_nom, entry_publique, frame_cles, on_configure):
    nom = entry_nom.get()

    if nom == "":
        return

    publique = entry_publique.get()

    hash_pub_key = sha256_hash(str(publique))

    show = f"{nom}  \n {hash_pub_key}\n"
    frame_cle = tk.Frame(frame_cles, pady=5)
    frame_cle.pack(fill=tk.X)  # Remplit l'espace horizontalement

    entry_name = tk.Entry(frame_cle, width=15)
    entry_name.insert(tk.END, nom)
    entry_name.pack(side=tk.LEFT, padx=(5, 0), pady=5)

    entry_cle = tk.Entry(frame_cle, width=40)
    entry_cle.insert(tk.END, hash_pub_key)
    entry_cle.pack(side=tk.LEFT, padx=5, pady=5)

    button_copier = ttk.Button(frame_cle, text="Use", width=2, command=lambda key=publique: copier_cle(key, nom))
    button_copier.pack(side=tk.LEFT, padx=5, pady=5)

    button_supprimer = ttk.Button(frame_cle, text="Delete", width=2, command=lambda frame=frame_cle, key=publique: confirmer_suppression(frame, key, nom))
    button_supprimer.pack(side=tk.LEFT, padx=5, pady=5)

    enregistrer_cle(nom, publique)
    on_configure(None)


def copier_cle(key, line):
    champ_clepublique.delete(0, tk.END)
    champ_clepublique.insert(tk.END, key)

    refresh_sha256()
    messagebox.showinfo("Access", "Access to the public key.")

    deuxieme_fenetre.destroy()


def copier_cle_cocobox(key, line):
    champ_clepublique.delete(0, tk.END)
    champ_clepublique.insert(tk.END, key)

    refresh_sha256()


def confirmer_suppression(frame_cle, key, nom):
    deuxieme_fenetre.lift()
    if messagebox.askyesno("Confirmation", "Are you sure you want to delete this public key?"):
        supprimer_cle(frame_cle, key, fenetre, nom)


def supprimer_cle(frame_cle, key, fenetre_principale, nom):
    frame_cle.destroy()
    supprimer_cle_fichier(key, nom)
    deuxieme_fenetre.lift()


def supprimer_cle_fichier(key, nom):
    with open("registre.txt", "r") as fichier:
        lignes = fichier.readlines()
    with open("registre.txt", "w") as fichier:
        for ligne in lignes:
            if f"Nom: {nom}" not in ligne:
                if f"Cle publique: {key}" not in ligne:
                    fichier.write(ligne)


def enregistrer_cle(nom, publique):
    with open("registre.txt", "a") as fichier:
        publique = str(publique)
        publique = publique.replace("(", " ").replace(")", " ").replace(",", " ")
        fichier.write(f"Nom: {nom}\nCle publique: {publique}\n")


def charger_registre(frame_cles,parent_width):
    try:
        with open("registre.txt", "r") as fichier:
            contenu = fichier.readlines()
            i = 0  # Utilisé pour suivre la position actuelle dans le contenu
            while i < len(contenu):
                if contenu[i].startswith("Nom:"):
                    nom = contenu[i].split(": ")[1].strip()  # Obtenir le nom correctement

                    if i + 1 < len(contenu) and contenu[i + 1].startswith("Cle publique:"):
                        publique = contenu[i + 1].split(": ")[1].strip()  # Obtenir la clé publique correctement

                        hash_pub_key = sha256_hash(str(publique))

                        nom_publique = nom + "  " + hash_pub_key
                        frame = tk.Frame(frame_cles)
                        frame.pack(fill=tk.X, pady=5)

                        entry_name = tk.Entry(frame, width=12,highlightbackground="gray", highlightcolor="gray", highlightthickness=1)
                        entry_name.insert(tk.END, nom)  # Utiliser le nom ici
                        entry_name.pack(side=tk.LEFT, padx=1)

                        entry_cle = tk.Entry(frame, width=50,highlightbackground="gray", highlightcolor="gray", highlightthickness=1)
                        entry_cle.insert(tk.END, hash_pub_key)  # Utiliser le nom ici
                        entry_cle.pack(side=tk.LEFT)

                        def copier_cle_callback(key=publique, nom=nom):
                            deuxieme_fenetre.destroy()# Utiliser les arguments par défaut
                            copier_cle(key, nom)

                        button_copier = ttk.Button(frame, text="Use", command=copier_cle_callback,width=10)
                        button_copier.pack(side=tk.LEFT, padx=5)

                        def supprimer_callback(key=publique, frame=frame, nom=nom):
                            confirmer_suppression(frame, key, nom)

                        button_supprimer = ttk.Button(frame, text="Delete", command=supprimer_callback,width=10)
                        button_supprimer.pack(side=tk.LEFT, padx=5)

                        # Passer à la ligne suivante après avoir traité le nom et la clé
                        i += 2
                    else:
                        # Si la clé publique n'est pas trouvée, passer à la ligne suivante
                        i += 1
                else:
                    # Passer à la ligne suivante si la ligne ne commence pas par "Nom:"
                    i += 1
    except FileNotFoundError:
        pass


def ouvrir_deuxieme_fenetre():
    global deuxieme_fenetre

    if deuxieme_fenetre is not None and deuxieme_fenetre.winfo_exists():
        deuxieme_fenetre.deiconify()
        return

    deuxieme_fenetre = tk.Toplevel(fenetre)
    deuxieme_fenetre.title("Public key management")

    parent_width = deuxieme_fenetre.winfo_width()
    print(parent_width)

    deuxieme_fenetre.geometry("750x500")
    deuxieme_fenetre.resizable(False, False)

    frame_ajout = tk.Frame(deuxieme_fenetre)
    frame_ajout.pack(pady=10)

    label_nom = tk.Label(frame_ajout, text="Name :")
    label_nom.grid(row=0, column=0, padx=10)
    entry_nom = ttk.Entry(frame_ajout)
    entry_nom.grid(row=0, column=1, padx=10, pady=2)

    label_publique = tk.Label(frame_ajout, text="Public key :")
    label_publique.grid(row=1, column=0, padx=10)
    entry_publique = ttk.Entry(frame_ajout)
    entry_publique.grid(row=1, column=1, padx=10)

    scrollbar = tk.Scrollbar(deuxieme_fenetre, orient=tk.VERTICAL)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    canvas = tk.Canvas(deuxieme_fenetre, yscrollcommand=scrollbar.set)
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    scrollbar.config(command=canvas.yview)

    frame_cles = tk.Frame(canvas)
    canvas.create_window((0, 0), window=frame_cles, anchor=tk.NW)

    def on_configure(event=None):
        canvas.configure(scrollregion=canvas.bbox("all"))

    button_ajouter = ttk.Button(frame_ajout, text="Add",
                                command=lambda: ajouter_cle(entry_nom, entry_publique, frame_cles, on_configure))
    button_ajouter.grid(row=2, columnspan=2, pady=10)

    charger_registre(frame_cles,parent_width)

    canvas.bind("<Configure>", on_configure)


deuxieme_fenetre = None


def supprimer():
    fenetre.withdraw()  # Masquer temporairement la fenêtre principale
    # Ajoutez ici le code de suppression
    fenetre.deiconify()


def generate_keys():
    if type == 5:

        private_key = generate_private_key()

        public_key = generate_public_key(private_key)

        return public_key, private_key

    else:
        global cle

        if cle == 1:
            key_size = 1024
        elif cle == 2:
            key_size = 2048
        elif cle == 3:
            key_size = 3072
        e = 65537  # e is often chosen as a small prime number for efficiency and security

        while True:
            # Generate random prime numbers with the desired key size using CSPRNG
            p = sympy.nextprime(int.from_bytes(os.urandom(key_size // 8), byteorder='big'))
            q = sympy.nextprime(int.from_bytes(os.urandom(key_size // 8), byteorder='big'))

            # Ensure p and q are different primes
            if p != q:
                break

        n = p * q
        phi = (p - 1) * (q - 1)

        # Find d using modular inverse (private key)
        d = pow(e, -1, phi)

        public_key = (e, n)
        private_key = (d, n)

        return public_key, private_key


def generate_keypair_in_thread():
    global cle

    def thread_target():
        public_key, private_key = generate_keys()

        return public_key, private_key

    thread = threading.Thread(target=thread_target)
    thread.start()


def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a


def modinv(a, m):
    g, x, y = gcd(a, m), 0, 1
    if g != 1:
        raise Exception('modular inverse does not exist')
    else:
        return pow(a, -1, m)


def encrypt(message, public_key):
    global rsa
    global sign

    if rsa == 1:
        block_size = 1
        encrypted_blocks = []
    elif rsa == 3:
        block_size = 3
        encrypted_blocks = []
    elif rsa == 100:
        block_size = 200
        encrypted_blocks = []

    # Pad the message with spaces to make its length divisible by the block size
    message = message.ljust(len(message) + (block_size - len(message) % block_size) % block_size)

    # Encrypt the message in blocks
    for i in range(0, len(message), block_size):
        block = message[i:i + block_size]
        block_int = int.from_bytes(block.encode('utf-8'), 'big')
        encrypted_block = encrypt_block(block_int, public_key)

        # Convert the encrypted block to bytes before encoding with base64
        encrypted_bytes = encrypted_block.to_bytes((encrypted_block.bit_length() + 7) // 8, byteorder='big')
        encrypted_base64 = base64.b64encode(encrypted_bytes).decode('utf-8')
        encrypted_blocks.append(encrypted_base64)

    return encrypted_blocks


def encryptprivee(message, public_key):
    try:
        e, n = public_key

    except Exception as e:
        open_key_access_window3()

    block_size = 3
    encrypted_blocks = []

    # Pad the message with spaces to make its length divisible by 3
    message = message.ljust(len(message) + (block_size - len(message) % block_size) % block_size)

    # Encrypt the message in blocks of 3 characters
    for i in range(0, len(message), block_size):
        block = message[i:i + block_size]
        block_int = int.from_bytes(block.encode('utf-8'), 'big')
        encrypted_block = encrypt_block(block_int, public_key)
        encrypted_blocks.append(str(encrypted_block))

    return encrypted_blocks


def decrypt(cle_hex, private_key):
    global type
    global sign
    try:
        d, n = private_key
    except Exception as e:
        open_key_access_window()

    if not champ_clepriver.get():
        open_key_access_window()

    elif sign == 1 and not champ_clepublique.get():
        ouvrir_deuxieme_fenetre()
    elif type == 2:
        cle_blocks = cle_hex
    elif type != 2:
        cle_blocks = cle_hex

    decrypted_blocks = []

    try:  # Decrypt each encrypted block and convert it back to the original string
        for encrypted_block in cle_blocks:
            encrypted_bytes = base64.b64decode(encrypted_block)  # Decode from base64
            encrypted_int = int.from_bytes(encrypted_bytes, 'big')  # Convert bytes to int
            decrypted_block = decrypt_block(encrypted_int, private_key)

            # Convert the decrypted block back to bytes before converting to string
            decrypted_bytes = decrypted_block.to_bytes((decrypted_block.bit_length() + 7) // 8, 'big')
            decrypted_blocks.append(decrypted_bytes.decode('utf-8'))

        decrypted_message = ''.join(decrypted_blocks).rstrip()

        return decrypted_message
    except Exception as e:
        messagebox.showerror("Error", "An error has occurred !")


def decryptprivee(cle_sign, cle_publique):
    try:
        e, n = cle_publique

    except Exception as e:
        open_key_access_window3()

    if not champ_clepriver.get():
        open_key_access_window()

    elif sign == 1 and not champ_clepublique.get():
        ouvrir_deuxieme_fenetre()
    elif type == 2:
        cle_blocks = cle_sign
    elif type != 2:
        cle_blocks = cle_sign

    decrypted_blocks = []

    # Decrypt each encrypted block and convert it back to the original string
    for encrypted_block in cle_blocks:
        encrypted_bytes = base64.b64decode(encrypted_block)  # Decode from base64
        encrypted_int = int.from_bytes(encrypted_bytes, 'big')  # Convert bytes to int
        decrypted_block = decrypt_block(encrypted_int, cle_publique)

        # Convert the decrypted block back to bytes before converting to string
        decrypted_bytes = decrypted_block.to_bytes((decrypted_block.bit_length() + 7) // 8, 'big')
        decrypted_blocks.append(decrypted_bytes.decode('utf-8'))

    decrypted_message = ''.join(decrypted_blocks).rstrip()

    return decrypted_message

def str_to_int(message):
    # Convert the string to an integer by joining the ASCII values of the characters
    return int(''.join(str(ord(c)).zfill(3) for c in message))


def int_to_str(integer):
    # Convert the integer back to the original string
    integer_str = str(integer)
    chars = [chr(int(integer_str[i:i + 3])) for i in range(0, len(integer_str), 3)]
    return ''.join(chars)


def encrypt_block(block, public_key):
    e, n = public_key
    return pow(block, e, n)


def decrypt_block(encrypted_block, private_key):
    d, n = private_key
    return pow(encrypted_block, d, n)


def crypter(cle_hex):
    cle_publique = tuple(map(int, champ_clepublique.get().split()))
    cle_privee = tuple(map(int, champ_clepriver.get().split()))
    message = champ_message.get("1.0", tk.END).strip()
    ciphertext = encrypt(cle_hex, cle_publique)
    champ_message.delete("1.0", tk.END)
    champ_message.insert("1.0", " ".join(ciphertext))
    return " ".join(ciphertext)  # Retourner le résultat du chiffrement


def decrypter(cle_hex):
    cle_privee = tuple(map(int, champ_clepriver.get().split()))

    cle_hex = decrypt(cle_hex, cle_privee)
    return cle_hex

def calculate_sha256_hash(text):
    sha256_hash = hashlib.sha256()
    sha256_hash.update(text.encode('utf-8'))
    return sha256_hash.hexdigest()


def import_keypair():
    global key_management_window1

    if key_management_window1 is not None:
        key_management_window1.deiconify()
        return

    key_management_window1 = tk.Toplevel(fenetre)
    key_management_window1.title("import a key pair")


    def on_key_management_window_close():
        global key_management_window1
        key_management_window1.destroy()
        key_management_window1 = None

    key_management_window1.protocol("WM_DELETE_WINDOW", on_key_management_window_close)

    label_clepublique = ttk.Label(key_management_window1, text="Public key:", font=("Helvetica", 12))
    label_clepublique.pack()
    champ_clepublique = ttk.Entry(key_management_window1, width=55)
    champ_clepublique.pack(padx=10)

    label_clepriver = ttk.Label(key_management_window1, text="Private key:", font=("Helvetica", 12))
    label_clepriver.pack()
    champ_clepriver = ttk.Entry(key_management_window1, width=55)
    champ_clepriver.pack()

    label_espace = ttk.Label(key_management_window1, text=" ", font=("Helvetica", 12))
    label_espace.pack()

    label_nom = ttk.Label(key_management_window1, text="Name:", font=("Helvetica", 12))
    label_nom.pack()
    champ_nom = ttk.Entry(key_management_window1, width=45)
    champ_nom.pack()

    label_password = ttk.Label(key_management_window1, text="Password:", font=("Helvetica", 12))
    label_password.pack()
    champ_password = ttk.Entry(key_management_window1, width=40, show="*")
    champ_password.pack()

    def save_key_pair():
        public_key = champ_clepublique.get().strip()
        private_key = champ_clepriver.get().strip()
        password = champ_password.get().strip()

        if public_key and private_key and password:
            if chiffrage == 1:
                # Conversion du mot de passe en une clé de 32 octets
                key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)

                # Encodage de la clé en base64
                encoded_key = base64.urlsafe_b64encode(key)

                # Création de l'objet Fernet avec la clé encodée
                cipher_suite = Fernet(encoded_key)

                # Chiffrement de la paire de clés avec la clé
                encrypted_public_key = cipher_suite.encrypt(public_key.encode('utf-8'))
                encrypted_private_key = cipher_suite.encrypt(private_key.encode('utf-8'))

                key_pair = f"Clé publique: {encrypted_public_key.decode('utf-8')}\nClé privée: {encrypted_private_key.decode('utf-8')}"
                with open("gestion_avancé.txt", "w") as file:
                    file.write(key_pair)
                    messagebox.showinfo("Saved", "The key pair has been saved successfully.")



            else:
                public_key = champ_clepublique.get().strip()
                private_key = champ_clepriver.get().strip()
                password = champ_password.get().strip()

                if public_key and private_key and password:
                    # Hachage du mot de passe avec SHA-256
                    password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()

                    hash_cle_priver = champ_clepublique.get().strip()
                    hash_cle_priver = hashlib.sha256(hash_cle_priver.encode('utf-8')).hexdigest()

                    global cle
                    global type

                    type_cle = "Unknow"

                    if type == 5:
                        type_cle = "ECIES 256 bits"
                    else:

                        if cle == 1:
                            type_cle = "RSA 1024 bits"
                        elif cle == 2:
                            type_cle = "RSA 2048 bits"
                        elif cle == 3:
                            type_cle = "RSA 3072 bits"

                    # Double hachage du hash du mot de passe avec SHA-256
                    double_hash = champ_nom.get().strip()

                    # Vérifier si le mot de passe existe déjà dans le fichier
                    with open("key_pairs.txt", "r+") as file:
                        lines = file.readlines()
                        double_hash = "Nom: " + double_hash
                        double_hash = double_hash.strip()
                        for i in range(0, len(lines), 4):

                            if any(line.strip() == double_hash for line in lines):
                                # Le mot de passe existe déjà, demander à l'utilisateur de confirmer le remplacement
                                if messagebox.askyesno("Confirmation",
                                                       "This password has already been used to saved a key pair. Do you want to replace the existing key?"):
                                    # Remplacer la clé existante
                                    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)
                                    encoded_key = base64.urlsafe_b64encode(key)
                                    cipher_suite = Fernet(encoded_key)

                                    encrypted_public_key = cipher_suite.encrypt(public_key.encode('utf-8'))
                                    encrypted_private_key = cipher_suite.encrypt(private_key.encode('utf-8'))

                                    lines[i + 1] = f"Public Key: {encrypted_public_key.decode('utf-8')}\n"
                                    lines[i + 2] = f"Private Key: {encrypted_private_key.decode('utf-8')}\n"

                                    # Écrire les modifications dans le fichier
                                    with open("key_pairs.txt", "w") as file:
                                        file.writelines(lines)

                                    messagebox.showinfo("Saved", "The key pair was successfully replaced.")
                                else:
                                    # Annuler l'enregistrement
                                    messagebox.showinfo("Saved canceled",
                                                        "Saved of the key pair has been canceled.")
                                return

                    # Le mot de passe n'existe pas encore, enregistrer la nouvelle paire de clés
                    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)
                    encoded_key = base64.urlsafe_b64encode(key)
                    cipher_suite = Fernet(encoded_key)

                    encrypted_public_key = cipher_suite.encrypt(public_key.encode('utf-8'))
                    encrypted_private_key = cipher_suite.encrypt(private_key.encode('utf-8'))

                    # Sauvegarde de la paire de clés chiffrées dans le fichier texte
                    with open("key_pairs.txt", "a") as file:
                        file.write(f"{double_hash}\n")
                        file.write(f"typecle: {type_cle}\n")
                        file.write(f"hash: {hash_cle_priver}\n")
                        file.write(f"Public Key: {encrypted_public_key.decode('utf-8')}\n")
                        file.write(f"Private Key: {encrypted_private_key.decode('utf-8')}\n")

                    messagebox.showinfo("Save", "The key pair has been saved successfully.")
                else:
                    messagebox.showerror("Error", "Please complete all fields.")

    boubon_enregsitrer = ttk.Button(key_management_window1, text="Saved", command=save_key_pair)
    boubon_enregsitrer.pack(pady=3)


def open_key_management_window():
    global key_management_window

    if key_management_window is not None:
        key_management_window.deiconify()
        return

    key_management_window = tk.Toplevel(fenetre)
    key_management_window.title("Key management")


    def on_key_management_window_close():
        global key_management_window
        key_management_window.destroy()
        key_management_window = None

    key_management_window.protocol("WM_DELETE_WINDOW", on_key_management_window_close)

    champ_clepublique = ttk.Entry(key_management_window, width=50)
    champ_clepublique.grid_forget()

    champ_clepriver = ttk.Entry(key_management_window, width=50)
    champ_clepriver.grid_forget()

    label_nom = ttk.Label(key_management_window, text="Name:", font=("Helvetica", 12))
    label_nom.grid(padx=20, row=0)
    champ_nom = ttk.Entry(key_management_window, width=45)
    champ_nom.grid(padx=20, row=1)

    label_password = ttk.Label(key_management_window, text="Password:", font=("Helvetica", 12))
    label_password.grid(row=2)
    champ_password = ttk.Entry(key_management_window, width=40, show="*")
    champ_password.grid(row=3)

    def bar_de_chargement():
        password = champ_password.get().strip()
        nom = champ_nom.get().strip()
        if not password:
            messagebox.showerror("Error", "please enter a name and password.")
            return
        root = tk.Toplevel()
        root.title("Generation of keys...")

        # Obtenir les dimensions de l'écran
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()

        # Calculer les coordonnées pour centrer la fenêtre de chargement
        window_width = 300
        window_height = 100
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2

        root.geometry(f"{window_width}x{window_height}+{x}+{y}")

        root.grab_set()  # Mettre la fenêtre en premier plan

        progress_bar = ttk.Progressbar(root, orient="horizontal", length=window_width - 20, mode="indeterminate")
        progress_bar.grid(pady=20)
        progress_bar.start()
        label_avercle = ttk.Label(root, text="Generating 3072-bit keys can take more than 3min",
                                  font=("Helvetica", 8))
        label_avercle.grid()
        root.update()
        root.after(2000, root.update)

        def thread_target():

            public_key, private_key = generate_keys()

            enregistrer_cle(nom, public_key)

            champ_clepublique.delete(0, tk.END)
            champ_clepriver.delete(0, tk.END)

            root.destroy()

            champ_clepublique.insert(tk.END, " ".join(str(x) for x in public_key))

            if type == 5:
                champ_clepriver.insert(tk.END, private_key)
            else:
                champ_clepriver.insert(tk.END, " ".join(str(x) for x in private_key))

            save_key_pair()

        thread = threading.Thread(target=thread_target)

        thread.start()

    bouton_generer = ttk.Button(key_management_window, text="Create a new key pair",
                                command=bar_de_chargement)
    bouton_generer.grid(pady=3, row=4)

    if type == 5:
        label_type_cle = ttk.Label(key_management_window, text="Currently in mode : ECIES 256 bits",
                                   font=("Helvetica", 11))
        label_type_cle.grid(pady=10, row=5)
    else:

        if cle == 2:
            label_type_cle = ttk.Label(key_management_window, text="Currently in mode : RSA 2048 bits",
                                       font=("Helvetica", 11))
            label_type_cle.grid(pady=10, row=5)
        elif cle == 1:
            label_type_cle = ttk.Label(key_management_window, text="Currently in mode : RSA 1024 bits ",
                                       font=("Helvetica", 11))
            label_type_cle.grid(pady=10, row=5)

        elif cle == 3:
            label_type_cle = ttk.Label(key_management_window, text="Currently in mode : RSA 3072 bits",
                                       font=("Helvetica", 11))
            label_type_cle.grid(pady=10, row=5)

    bouton_advanced = ttk.Button(key_management_window, text="advanced",
                                 command=lambda: advanced_windows_fonction(label_type_cle))
    bouton_advanced.grid(pady=3, padx=3, sticky="e", row=6)

    def save_key_pair():
        public_key = champ_clepublique.get().strip()
        private_key = champ_clepriver.get().strip()
        password = champ_password.get().strip()

        if public_key and private_key and password:
            if chiffrage == 1:
                # Conversion du mot de passe en une clé de 32 octets
                key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)

                # Encodage de la clé en base64
                encoded_key = base64.urlsafe_b64encode(key)

                # Création de l'objet Fernet avec la clé encodée
                cipher_suite = Fernet(encoded_key)

                # Chiffrement de la paire de clés avec la clé
                encrypted_public_key = cipher_suite.encrypt(public_key.encode('utf-8'))
                encrypted_private_key = cipher_suite.encrypt(private_key.encode('utf-8'))

                key_pair = f"Clé publique: {encrypted_public_key.decode('utf-8')}\nClé privée: {encrypted_private_key.decode('utf-8')}"
                with open("gestion_avancé.txt", "w") as file:
                    file.write(key_pair)
                    messagebox.showinfo("Save", "The key pair has been saved successfully.")
                key_management_window.withdraw()
                show_private_key_certificat()



            else:
                public_key = champ_clepublique.get().strip()
                private_key = champ_clepriver.get().strip()
                password = champ_password.get().strip()

                if public_key and private_key and password:
                    # Hachage du mot de passe avec SHA-256
                    password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()

                    hash_cle_priver = champ_clepublique.get().strip()
                    hash_cle_priver = hashlib.sha256(hash_cle_priver.encode('utf-8')).hexdigest()

                    global cle

                    type_cle = "Unknow"

                    if type == 5:
                        type_cle = "ECIES 256 bits"
                    else:

                        if cle == 1:
                            type_cle = "RSA 1024 bits"
                        elif cle == 2:
                            type_cle = "RSA 2048 bits"
                        elif cle == 3:
                            type_cle = "RSA 3072 bits"

                    # Double hachage du hash du mot de passe avec SHA-256
                    double_hash = champ_nom.get().strip()

                    # Vérifier si le mot de passe existe déjà dans le fichier
                    with open("key_pairs.txt", "r+") as file:
                        lines = file.readlines()
                        double_hash = "Nom: " + double_hash
                        double_hash = double_hash.strip()
                        for i in range(0, len(lines), 4):

                            if any(line.strip() == double_hash for line in lines):
                                # Le mot de passe existe déjà, demander à l'utilisateur de confirmer le remplacement
                                if messagebox.askyesno("Confirmation",
                                                       "This name has already been used to saved a key pair. Do you want to replace the existing key?"):
                                    # Remplacer la clé existante
                                    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)
                                    encoded_key = base64.urlsafe_b64encode(key)
                                    cipher_suite = Fernet(encoded_key)

                                    encrypted_public_key = cipher_suite.encrypt(public_key.encode('utf-8'))
                                    encrypted_private_key = cipher_suite.encrypt(private_key.encode('utf-8'))

                                    lines[i + 1] = f"Public Key: {encrypted_public_key.decode('utf-8')}\n"
                                    lines[i + 2] = f"Private Key: {encrypted_private_key.decode('utf-8')}\n"

                                    # Écrire les modifications dans le fichier
                                    with open("key_pairs.txt", "w") as file:
                                        file.writelines(lines)

                                    messagebox.showinfo("Saved", "The key pair was successfully replaced.")
                                else:
                                    # Annuler l'enregistrement
                                    messagebox.showinfo("Save canceled",
                                                        "The key pair save has been canceled.")
                                return

                    # Le mot de passe n'existe pas encore, enregistrer la nouvelle paire de clés
                    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)
                    encoded_key = base64.urlsafe_b64encode(key)
                    cipher_suite = Fernet(encoded_key)

                    encrypted_public_key = cipher_suite.encrypt(public_key.encode('utf-8'))
                    encrypted_private_key = cipher_suite.encrypt(private_key.encode('utf-8'))

                    # Sauvegarde de la paire de clés chiffrées dans le fichier texte
                    with open("key_pairs.txt", "a") as file:
                        file.write(f"{double_hash}\n")
                        file.write(f"typecle: {type_cle}\n")
                        file.write(f"hash: {hash_cle_priver}\n")
                        file.write(f"Public Key: {encrypted_public_key.decode('utf-8')}\n")
                        file.write(f"Private Key: {encrypted_private_key.decode('utf-8')}\n")

                    messagebox.showinfo("Saved", "The key pair has been saved successfully.")
                    key_management_window.withdraw()
                    show_private_key_certificat()
                else:
                    messagebox.showerror("Error", "Please complete all fields.")


advanced_windows = None


def advanced_windows_fonction(label_type_cle):
    global advanced_windows

    if advanced_windows is not None and advanced_windows.winfo_exists():
        advanced_windows.deiconify()
        return

    def update_checkboxes(checkbox):
        if checkbox == checkbox2:
            checkbox2.select()
            checkbox1.deselect()
            checkbox2.config(state='disabled')
            checkbox1.config(state='normal')
        elif checkbox == checkbox1:
            checkbox1.select()
            checkbox2.deselect()
            checkbox1.config(state='disabled')
            checkbox2.config(state='normal')

    def fermer_advanced(checkbox2_var, label_type_cle):
        global cle
        global type

        if checkbox1_var.get() == 1:
            if combobox1.get() == "1024 bits":
                cle = 1
                type = 1
                label_type_cle.config(text="Currently in mode : RSA 1024 bits")
            elif combobox1.get() == "2048 bits":
                cle = 2
                type = 1
                label_type_cle.config(text="Currently in mode : RSA 2048 bits")
            elif combobox1.get() == "3072 bits":
                cle = 3
                type = 1
                label_type_cle.config(text="Currently in mode : RSA 3072 bits")
        else:
            label_type_cle.config(text="Currently in mode : ECIES 256 bits")
            type = 5

        advanced_windows.destroy()

    advanced_windows = tk.Toplevel(key_management_window)
    advanced_windows.title("key type")

    checkbox1_var = tk.IntVar()
    checkbox2_var = tk.IntVar()

    checkbox1 = tk.Checkbutton(advanced_windows, text="RSA", variable=checkbox1_var,
                               command=lambda: update_checkboxes(checkbox1))
    checkbox2 = tk.Checkbutton(advanced_windows, text="ECIES", variable=checkbox2_var,
                               command=lambda: update_checkboxes(checkbox2))

    checkbox1.grid(row=0, column=0, pady=5, sticky="W")
    checkbox2.grid(row=1, column=0, sticky="W")

    combo_values1 = ["1024 bits", "2048 bits", "3072 bits"]
    combobox1 = ttk.Combobox(advanced_windows, values=combo_values1, width=10)
    combobox1.grid(row=0, column=1, padx=10)

    if cle == 1:
        combobox1.set("1024 bits")
    elif cle == 2:
        combobox1.set("2048 bits")
    elif cle == 3:
        combobox1.set("3072 bits")

    combo_values2 = ["256 bits"]
    combobox2 = ttk.Combobox(advanced_windows, values=combo_values2, width=10)
    combobox2.grid(row=1, column=1, padx=10)

    # Définir une valeur par défaut pour le Combobox
    combobox2.set("256 bits")

    button = ttk.Button(advanced_windows, text="ok", command=lambda: fermer_advanced(checkbox2_var, label_type_cle))
    button.grid(row=2, pady=15, column=1, sticky="W")

    global type

    if type == 5:
        checkbox2.select()
        checkbox2.config(state='disabled')
    else:
        checkbox1.select()
        checkbox1.config(state='disabled')


def destroy_key_management_window():
    global key_management_window

    if key_management_window is not None:
        key_management_window.withdraw()


def destroy_key_access_window():
    global key_access_window

    if key_access_window is not None:
        key_access_window.withdraw()


def copy_result():
    result = champ_message.get("1.0", tk.END)
    if result:
        pyperclip.copy(result)


def encryptaes(message, key):
    backend = default_backend()
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
    encryptor = cipher.encryptor()
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(message.encode()) + padder.finalize()
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    return iv + ciphertext


def decryptaes(ciphertext, key):
    backend = default_backend()
    iv = ciphertext[:16]
    ciphertext = ciphertext[16:]
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
    decryptor = cipher.decryptor()
    unpadder = padding.PKCS7(128).unpadder()
    decrypted_data = decryptor.update(ciphertext) + decryptor.finalize()
    message = unpadder.update(decrypted_data) + unpadder.finalize()
    return message.decode()


def ouvrir_type_chiffrage():
    global type_chiffrage
    # Vérifier si la deuxième fenêtre est déjà ouverte
    if type_chiffrage is not None and type_chiffrage.winfo_exists():
        type_chiffrage.deiconify()
        return
    type_chiffrage = tk.Toplevel(fenetre)
    type_chiffrage.title("Parameters")

    def fenetreferme1():
        type_chiffrage.destroy()
        global type
        global chiffrage
        type = 1
        chiffrage = 2
        type2.set("AES+RSA")
        label_typechiffrage2.config(text=type2.get())

    def fenetreferme2():
        type_chiffrage.destroy()
        global type
        global chiffrage
        type = 3
        chiffrage = 2
        type2.set("AES")
        label_typechiffrage2.config(text=type2.get())

    def fenetreferme3():
        type_chiffrage.destroy()
        global type
        global chiffrage
        type = 2
        chiffrage = 2
        type2.set("RSA")
        label_typechiffrage2.config(text=type2.get())

    def fenetreferme4():
        type_chiffrage.destroy()
        global type
        global chiffrage
        type = 4
        chiffrage = 2
        type2.set("No encryption")
        label_typechiffrage2.config(text=type2.get())

    def fenetreferme5():
        type_chiffrage.destroy()
        global type
        global chiffrage
        type = 5
        chiffrage = 2
        type2.set("ecies")
        label_typechiffrage2.config(text=type2.get())

    label_taille = ttk.Label(type_chiffrage, text="Encryption Type :", font=("Helvetica", 12))
    label_taille.pack(pady=5)

    label_taille = ttk.Label(type_chiffrage, text="Hybrid Encryption (recommended) :", font=("Helvetica", 10))
    label_taille.pack(pady=5)

    label_taille = ttk.Label(type_chiffrage, text="On Prime Numbers :", font=("Helvetica", 8))
    label_taille.pack(pady=5)

    bouton_access = ttk.Button(type_chiffrage, text="AES + RSA", command=fenetreferme1)
    bouton_access.pack(ipady=2)

    label_taille = ttk.Label(type_chiffrage, text="On Elliptic Curve :", font=("Helvetica", 8))
    label_taille.pack(pady=5)

    bouton_access = ttk.Button(type_chiffrage, text="ecies + sign Ecdsa", command=fenetreferme5)
    bouton_access.pack(ipady=2)

    label_taille = ttk.Label(type_chiffrage, text="   ", font=("Helvetica", 8))
    label_taille.pack()

    label_taille = ttk.Label(type_chiffrage, text="Solo symetric and asymetric Encryption :", font=("Helvetica", 9))
    label_taille.pack(pady=5)

    bouton_access = ttk.Button(type_chiffrage, text="AES (sym)", width=9, command=fenetreferme2)
    bouton_access.pack()

    bouton_access = ttk.Button(type_chiffrage, text="RSA (asy)", width=8, command=fenetreferme3)
    bouton_access.pack()

    label_taille = ttk.Label(type_chiffrage, text="   ", font=("Helvetica", 8))
    label_taille.pack()

    label_taille = ttk.Label(type_chiffrage, text="Without Encryption :", font=("Helvetica", 9))
    label_taille.pack()

    bouton_access = ttk.Button(type_chiffrage, text="no encryption", command=fenetreferme4)
    bouton_access.pack(pady=5, ipady=2)

    if type == 1:
        label_type_cle = ttk.Label(type_chiffrage, text="Currently in mode : AES + RSA", font=("Helvetica", 12))
        label_type_cle.pack(pady=10, padx=7)
    elif type == 3:
        label_type_cle = ttk.Label(type_chiffrage, text="Currently in mode : AES ", font=("Helvetica", 12))
        label_type_cle.pack(pady=10, padx=7)
    elif type == 2:
        label_type_cle = ttk.Label(type_chiffrage, text="Currently in mode : RSA ", font=("Helvetica", 12))
        label_type_cle.pack(pady=10, padx=7)
    elif type == 4:
        label_type_cle = ttk.Label(type_chiffrage, text="Currently in mode : Aucun chiffrement ",
                                   font=("Helvetica", 12))
        label_type_cle.pack(pady=10, padx=7)

    elif type == 5:
        label_type_cle = ttk.Label(type_chiffrage, text="Currently in mode : ecies + sign Ecdsa",
                                   font=("Helvetica", 12))
        label_type_cle.pack(pady=10, padx=7)

    def fermer_parametres():
        parametres.destroy()


type_chiffrage = None


def type_signature():
    global sign
    global sign2
    if sign == 1:
        sign = 2
        sign2.set("Disable")
        label_typechiffrage2.config(text=sign2.get())

    elif sign != 1:
        sign = 1
        sign2.set("Enable")
        label_typechiffrage2.config(text=sign2.get())


def insert_newlines_with_tags(s, every):
    parts = s.split('\n')  # Divise le texte en lignes existantes
    new_parts = []

    for part in parts:
        if part.startswith('---') and part.endswith('---'):
            new_parts.append(part)  # Les balises sont traitées comme une ligne entière
        else:
            new_parts.extend([part[i:i + every] for i in range(0, len(part), every)])

    return '\n'.join(new_parts)


def crypteraes():
    if type == 1 and not champ_clepublique.get():
        ouvrir_deuxieme_fenetre()
        return

    if type == 5 and not champ_clepublique.get():
        ouvrir_deuxieme_fenetre()
        return

    elif type == 2 and not champ_clepublique.get():
        ouvrir_deuxieme_fenetre()
        return

    if sign == 1 and not champ_clepriver.get():
        liste_certificat()

    else:
        generate_and_display_aes_key()

        def bar_de_chargement():
            root = tk.Toplevel()
            root.title("encryption...")

            # Obtenir les dimensions de l'écran
            screen_width = root.winfo_screenwidth()
            screen_height = root.winfo_screenheight()

            # Calculer les coordonnées pour centrer la fenêtre de chargement
            window_width = 300
            window_height = 100
            x = (screen_width - window_width) // 2
            y = (screen_height - window_height) // 2

            root.geometry(f"{window_width}x{window_height}+{x}+{y}")

            root.grab_set()  # Mettre la fenêtre en premier plan

            progress_bar = ttk.Progressbar(root, orient="horizontal", length=window_width - 20, mode="indeterminate")
            progress_bar.pack(pady=20)
            progress_bar.start()

            def crypteraes_thread():
                root.update()
                if chiffrage == 1:

                    # Récupérer la clé
                    public_key = champ_clepublique.get().strip()
                    cle_hex = champ_cle.get()
                    cle = bytes.fromhex(cle_hex)
                    # Récupérer le message à crypter
                    message = champ_message.get("1.0", tk.END).strip()  # Récupérer le texte depuis le widget Text
                    data = message
                    hasher = hashes.Hash(hashes.SHA256(), backend=default_backend())
                    hasher.update(data.encode('utf-8'))
                    hash_value = hasher.finalize()
                    cle_hex = encrypt1(cle_hex, public_key)
                    ciphertext = encryptaes(message, cle)
                    ciphertext_with_key = f"---Start AES key---\n{cle_hex}\n---End AES key---\n{ciphertext.hex()}"
                    # Afficher le texte chiffré
                    champ_message.delete('1.0', tk.END)
                    champ_message.insert(tk.END, ciphertext_with_key)

                else:
                    if type == 1:
                        # Récupérer la clé
                        cle_hex = champ_cle.get()
                        cle = bytes.fromhex(cle_hex)
                        # Récupérer le message à crypter
                        message = champ_message.get("1.0", tk.END).strip()  # Récupérer le texte depuis le widget Text
                        data = message
                        hasher = hashes.Hash(hashes.SHA256(), backend=default_backend())
                        hasher.update(data.encode('utf-8'))
                        hash_value = hasher.finalize()
                        if sign == 1:
                            hashmessage = hash_value.hex()

                            cle_privee = tuple(map(int, champ_clepriver.get().split()))

                            cle_hex1 = encrypt(hashmessage, cle_privee)
                            cle_hex1_str = " ".join(str(x) for x in
                                                    cle_hex1)  # Convertir les éléments de la liste en chaînes de caractères et les concaténer

                            # Ajouter "Start AES key", la clé AES en hexadécimal et "End AES key" avant et après le message chiffré
                            cle_hex1_str = cle_hex1_str
                            cle_hex = crypter(cle_hex)
                            ciphertext = encryptaes(message, cle)

                            ciphertext_base64 = base64.b64encode(ciphertext).decode('utf-8')

                            ciphertext_with_key = f"---Start Signature---\n{cle_hex1_str}\n---End Signature---\n" \
                                                  f"---Start AES key---\n{cle_hex}\n---End AES key---\n{ciphertext_base64}"
                            # Afficher le texte chiffré
                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, ciphertext_with_key)

                        if sign != 1:
                            # Ajouter "Start AES key", la clé AES en hexadécimal et "End AES key" avant et après le message chiffré

                            cle_hex = crypter(cle_hex)
                            ciphertext = encryptaes(message, cle)
                            ciphertext_base64 = base64.b64encode(ciphertext).decode('utf-8')
                            ciphertext_with_key = f"---Start AES key---\n{cle_hex}\n---End AES key---\n{ciphertext_base64}"

                            # Afficher le texte chiffré
                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, ciphertext_with_key)


                    elif type == 2:
                        message = champ_message.get("1.0", tk.END).strip()  # Récupérer le texte depuis le widget Text
                        data = message
                        hasher = hashes.Hash(hashes.SHA256(), backend=default_backend())
                        hasher.update(data.encode('utf-8'))
                        hash_value = hasher.finalize()
                        if sign == 1:

                            hashmessage = hash_value.hex()

                            cle_publique = tuple(map(int, champ_clepublique.get().split()))
                            cle_privee = tuple(map(int, champ_clepriver.get().split()))

                            cle_hex1 = encrypt(hashmessage, cle_privee)
                            cle_hex1_str = " ".join(str(x) for x in
                                                    cle_hex1)  # Convertir les éléments de la liste en chaînes de caractères et les concaténer

                            # Ajouter "Start AES key", la clé AES en hexadécimal et "End AES key" avant et après le message chiffré
                            cle_hex1_str = cle_hex1_str

                            ciphertext = crypter(message)
                            ciphertext_with_key = f"---Start Signature---\n{cle_hex1_str}\n---End Signature---\n{ciphertext}"
                            # Afficher le texte chiffré
                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, ciphertext_with_key)
                        else:
                            cle_publique = tuple(map(int, champ_clepublique.get().split()))
                            cle_privee = tuple(map(int, champ_clepriver.get().split()))
                            message = champ_message.get("1.0", tk.END).strip()
                            message = encrypt(message, cle_publique)
                            message = " ".join(str(x) for x in message)
                            champ_message.delete("1.0", tk.END)
                            champ_message.insert("1.0", message)

                    elif type == 3:
                        message = champ_message.get("1.0", tk.END)
                        message = message.strip()

                        messagehash = sha256_hash(message)

                        # Récupérer la clé
                        cle_hex = champ_cle.get()
                        cle = bytes.fromhex(cle_hex)
                        # Récupérer le message à crypter
                        message = champ_message.get("1.0", tk.END).strip()  # Récupérer le texte depuis le widget Text
                        data = message
                        hasher = hashes.Hash(hashes.SHA256(), backend=default_backend())
                        hasher.update(data.encode('utf-8'))
                        hash_value = hasher.finalize()

                        ciphertext = encryptaes(message, cle)
                        ciphertext_with_key = base64.b64encode(ciphertext).decode('utf-8')

                        if sign == 1:

                            hashmessage = hash_value.hex()

                            cle_privee = tuple(map(int, champ_clepriver.get().split()))

                            cle_hex1 = encrypt(hashmessage, cle_privee)
                            cle_hex1_str = " ".join(str(x) for x in
                                                    cle_hex1)  # Convertir les éléments de la liste en chaînes de caractères et les concaténer
                            ciphertext_base64 = base64.b64encode(ciphertext).decode('utf-8')

                            ciphertext_with_key = f"---Start Signature---\n{cle_hex1_str}\n---End Signature---\n{ciphertext_base64}"
                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, ciphertext_with_key)
                        else:
                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, ciphertext_with_key)
                    elif type == 4:
                        message = champ_message.get("1.0", tk.END)
                        message = message.strip()

                        messagehash = sha256_hash(message)

                        # Récupérer la clé
                        cle_hex = champ_cle.get()
                        cle = bytes.fromhex(cle_hex)
                        # Récupérer le message à crypter
                        message = champ_message.get("1.0", tk.END).strip()  # Récupérer le texte depuis le widget Text
                        data = message
                        hasher = hashes.Hash(hashes.SHA256(), backend=default_backend())
                        hasher.update(data.encode('utf-8'))
                        hash_value = hasher.finalize()

                        ciphertext = message

                        if sign == 1:
                            hashmessage = hash_value.hex()

                            cle_privee = tuple(map(int, champ_clepriver.get().split()))

                            cle_hex1 = encrypt(hashmessage, cle_privee)
                            cle_hex1_str = " ".join(str(x) for x in
                                                    cle_hex1)  # Convertir les éléments de la liste en chaînes de caractères et les concaténer
                            ciphertext_base64 = message

                            ciphertext_with_key = f"{ciphertext_base64}\n---Start Signature---\n{cle_hex1_str}\n---End Signature---"

                            ciphertext_with_key = insert_newlines_with_tags(ciphertext_with_key, 64)
                            ciphertext_with_key = f"---BEGIN SIGN CRRO MESSAGE---\n{ciphertext_with_key}\n---END SIGN CRRO MESSAGE---"
                            # Afficher le texte chiffré avec les balises
                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, ciphertext_with_key)

                    elif type == 5:

                        gx, gy = champ_clepublique.get().split()

                        public_key = int(gx), int(gy)

                        message = champ_message.get("1.0", tk.END).strip()

                        random_int_on_curve, encrypted_message = encrypt_message(public_key, message)

                        random_int_on_curve = ' '.join(str(random_int_on_curve)).encode('utf-8')

                        random_int_on_curve = base64.b64encode(random_int_on_curve).decode('utf-8')

                        encrypted_message = encrypted_message.decode('utf-8')

                        if sign == 1:

                            private_key = int(champ_clepriver.get())

                            signature = ecdsa_signature(private_key, message)

                            signature = ' '.join(str(signature)).encode("utf-8")

                            signature_base64 = base64.b64encode(signature).decode("utf-8")

                            ciphertext_all = f"---Start Signature---\n{signature_base64}\n---End Signature---\n" \
                                             f"---BEGIN CURVE INT---\n{random_int_on_curve}\n---END CURVE INT---\n{encrypted_message}"

                            ciphertext_all = insert_newlines_with_tags(ciphertext_all,
                                                                       64)

                            ciphertext_all = f"---BEGIN CRRO MESSAGE---\n{ciphertext_all}\n---END CRRO MESSAGE---"

                            champ_message.delete("1.0", tk.END)
                            champ_message.insert(tk.END, ciphertext_all)

                        else:

                            ciphertext_all = f"---BEGIN CURVE INT---\n{random_int_on_curve}\n---END CURVE INT---\n{encrypted_message}"

                            ciphertext_all = insert_newlines_with_tags(ciphertext_all,
                                                                       64)

                            ciphertext_all = f"---BEGIN CRRO MESSAGE---\n{ciphertext_all}\n---END CRRO MESSAGE---"

                            champ_message.delete("1.0", tk.END)
                            champ_message.insert(tk.END, ciphertext_all)

                    # À la fin de la fonction crypteraes_thread
                    if type == 1:
                        ciphertext_with_key = insert_newlines_with_tags(ciphertext_with_key,
                                                                        64)  # Insérer un saut de ligne tous les 64 caractères

                        ciphertext_with_key = f"---BEGIN CRRO MESSAGE---\n{ciphertext_with_key}\n---END CRRO MESSAGE---"
                        # Afficher le texte chiffré avec les balises
                        champ_message.delete('1.0', tk.END)
                        champ_message.insert(tk.END, ciphertext_with_key)

                    fenetre.after(1, root.destroy)

            threading.Thread(target=crypteraes_thread).start()

        bar_de_chargement()


def sha256_hash(input_str):
    # Convertir la chaîne en bytes, car hashlib fonctionne avec des bytes
    input_bytes = input_str.encode('utf-8')

    # Créer un objet de hachage SHA-256
    sha256_hash_obj = hashlib.sha256()

    # Mettre à jour le hachage avec les données de la chaîne
    sha256_hash_obj.update(input_bytes)

    # Obtenir le hachage en format hexadécimal
    hashed_str = sha256_hash_obj.hexdigest()

    return hashed_str


# Fonction pour décrypter le message

def decrypteraes():
    if type == 1 and not champ_clepriver.get():
        liste_certificat()
        return

    elif type == 2 and not champ_clepriver.get():
        liste_certificat()
        return

    elif type == 5 and not champ_clepriver.get():
        liste_certificat()
        return

    if sign == 1 and not champ_clepublique.get():
        ouvrir_deuxieme_fenetre()

    else:
        def bar_de_chargement():
            root = tk.Toplevel()
            root.title("Decryption...")

            # Obtenir les dimensions de l'écran
            screen_width = root.winfo_screenwidth()
            screen_height = root.winfo_screenheight()

            # Calculer les coordonnées pour centrer la fenêtre de chargement
            window_width = 300
            window_height = 100
            x = (screen_width - window_width) // 2
            y = (screen_height - window_height) // 2

            root.geometry(f"{window_width}x{window_height}+{x}+{y}")

            root.grab_set()  # Mettre la fenêtre en premier plan

            progress_bar = ttk.Progressbar(root, orient="horizontal", length=window_width - 20, mode="indeterminate")
            progress_bar.pack(pady=20)
            progress_bar.start()

            def decrypteraes_thread():
                root.update()

                if chiffrage == 1:
                    private_key = champ_clepriver.get().strip()
                    # Récupérer le texte chiffré
                    ciphertext_with_key = champ_message.get('1.0', tk.END).strip()
                    # Extraire la clé et le message chiffré
                    start_marker = "---Start AES key---"
                    end_marker = "---End AES key---"
                    if start_marker not in ciphertext_with_key or end_marker not in ciphertext_with_key:
                        messagebox.showerror("Error",
                                             "Missing AES key in ciphertext, or missing private key.")
                        return
                    start_index = ciphertext_with_key.index(start_marker) + len(start_marker)
                    end_index = ciphertext_with_key.index(end_marker)
                    cle_hex = ciphertext_with_key[start_index:end_index].strip()
                    cle_hex = decrypt1(cle_hex, private_key)
                    message_hex = ciphertext_with_key[end_index + len(end_marker):].strip()

                    # Convertir la clé et le message hexadécimaux en chaînes d'octets (bytes)
                    cle = bytes.fromhex(cle_hex)
                    message = bytes.fromhex(message_hex)
                    # Appeler la fonction decrypt() pour décrypter le message
                    plaintext = decryptaes(message, cle)
                    # Afficher le message décrypté
                    champ_message.delete('1.0', tk.END)
                    champ_message.insert(tk.END, plaintext)
                    message = champ_message.get("1.0", tk.END).strip()  # Récupérer le texte depuis le widget Text
                    data = message
                    hasher = hashes.Hash(hashes.SHA256(), backend=default_backend())
                    hasher.update(data.encode('utf-8'))
                    hash_value = hasher.finalize()
                else:
                    ciphertext_with_key1 = champ_message.get('1.0', tk.END).strip()
                    start_marker = "---BEGIN CRRO MESSAGE---"
                    end_marker = "---END CRRO MESSAGE---"
                    if start_marker in ciphertext_with_key1 and end_marker in ciphertext_with_key1:
                        start_index = ciphertext_with_key1.index(start_marker) + len(start_marker)
                        end_index = ciphertext_with_key1.index(end_marker)
                        ciphertext_with_key = ciphertext_with_key1[start_index:end_index].strip()

                    if type == 1:

                        try:

                            # Extraire la clé et le message chiffré
                            start_marker = "---Start AES key---"
                            end_marker = "---End AES key---"
                            if start_marker not in ciphertext_with_key or end_marker not in ciphertext_with_key:
                                messagebox.showerror("Error",
                                                     "Missing AES key in ciphertext, or missing private key.")
                                return
                            start_index = ciphertext_with_key.index(start_marker) + len(start_marker)
                            end_index = ciphertext_with_key.index(end_marker)
                            cle_hex = ciphertext_with_key[start_index:end_index].strip()
                            cle_hex = cle_hex.replace(" ", "").replace("\n", "")
                            cle_hex = cle_hex.split()
                            cle_hex = decrypter(cle_hex)
                            message_hex = ciphertext_with_key[end_index + len(end_marker):].strip()
                            message_hex = message_hex.replace(" ", "").replace("\n", "")

                            message_base64 = ciphertext_with_key[end_index + len(end_marker):].strip()
                            message_hex = base64.b64decode(message_base64).hex()

                            # Convertir la clé et le message hexadécimaux en chaînes d'octets (bytes)
                            cle = bytes.fromhex(cle_hex)
                            message = bytes.fromhex(message_hex)
                            # Appeler la fonction decrypt() pour décrypter le message
                            plaintext = decryptaes(message, cle)
                            # Afficher le message décrypté
                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, plaintext)
                            message = champ_message.get("1.0",
                                                        tk.END).strip()  # Récupérer le texte depuis le widget Text
                            data = message
                            hasher = hashes.Hash(hashes.SHA256(), backend=default_backend())
                            hasher.update(data.encode('utf-8'))
                            hash_value = hasher.finalize()

                            hashmessage = hash_value.hex()
                        except Exception as e:
                            pass

                        if sign == 1:
                            start_marker = "---Start Signature---"
                            end_marker = "---End Signature---"

                            try:
                                start_index = ciphertext_with_key.index(start_marker) + len(start_marker)
                                end_index = ciphertext_with_key.index(end_marker)
                                cle_sign = ciphertext_with_key[start_index:end_index].strip()
                                cle_sign = cle_sign.replace(" ", "").replace("\n", "")
                                cle_sign = cle_sign.split()

                                cle_publique = tuple(map(int, champ_clepublique.get().split()))
                                cle_publiqueaff = (champ_clepublique.get)()

                                sha256dechiffre = decryptprivee(cle_sign, cle_publique)
                                if sha256dechiffre == hashmessage:
                                    if messagebox.askyesno("Signature verified",
                                                           "The author of this message is (SHA256) : " + "\n   " + sha256_hash(
                                                               cle_publiqueaff) + "\n   " + "\nDo you want to see the full public key?"):
                                        # Annuler l'enregistrement
                                        messagebox.showinfo("Signature ",
                                                            "public key :" + cle_publiqueaff)
                                else:
                                    messagebox.showwarning("Invalid or missing signature",
                                                           "You can't be sure who wrote this message.")
                            except Exception as e:
                                messagebox.showwarning("Invalid or missing signature",
                                                       "You can't be sure who wrote this message.")
                                print("Erreur :", e)
                    elif type == 2:
                        message = champ_message.get("1.0", tk.END).strip()  # Récupérer le texte depuis le widget Text
                        data = message
                        hasher = hashes.Hash(hashes.SHA256(), backend=default_backend())
                        hasher.update(data.encode('utf-8'))
                        hash_value = hasher.finalize()

                        hashmessage = hash_value.hex()

                        ciphertext_with_key = champ_message.get('1.0', tk.END).strip()

                        if sign == 1:

                            start_marker = "---Start Signature---"
                            end_marker = "---End Signature---"

                            cle_publique = tuple(map(int, champ_clepublique.get().split()))

                            try:
                                start_index = ciphertext_with_key.index(start_marker) + len(start_marker)
                                end_index = ciphertext_with_key.index(end_marker)
                                cle_sign = ciphertext_with_key[start_index:end_index].strip()

                                sha256dechiffre = decrypt(cle_sign, cle_publique)
                                if sha256dechiffre == hashmessage:
                                    cle_publique = str(cle_publique)
                                    messagebox.showinfo("Signature verified",
                                                        "The author of this message is : " + cle_publique)
                                else:
                                    messagebox.showwarning("Invalid or missing signature",
                                                           "You can't be sure who wrote this message.")
                            except Exception as e:
                                messagebox.showerror("Signing problem",
                                                     "The signature is not compatible with simple RSA mode, deactivate the signature in the parameter or try to verify it by hand.")
                                print("Erreur :", e)
                        else:

                            cle_publique = tuple(map(int, champ_clepublique.get().split()))
                            cle_privee = tuple(map(int, champ_clepriver.get().split()))
                            ciphertext = champ_message.get("1.0", tk.END).split()

                            message = decrypt(ciphertext, cle_privee)
                            champ_message.delete("1.0", tk.END)
                            champ_message.insert(tk.END, message)

                    elif type == 3:

                        cle_hex = champ_cle.get()
                        cle = bytes.fromhex(cle_hex)

                        message = champ_message.get('1.0', tk.END).strip()

                        message_hex = message.strip()

                        # Convertir la clé et le message hexadécimaux en chaînes d'octets (bytes)
                        cle = bytes.fromhex(cle_hex)

                        if sign == 1:
                            start_marker = "---Start Signature---"
                            end_marker = "---End Signature---"
                            ciphertext_with_key = champ_message.get('1.0', tk.END).strip()

                            cle_publique = tuple(map(int, champ_clepublique.get().split()))

                            try:
                                start_index = ciphertext_with_key.index(start_marker) + len(start_marker)
                                end_index = ciphertext_with_key.index(end_marker)
                                cle_sign = ciphertext_with_key[start_index:end_index].strip()
                                cle_sign = cle_sign.split()

                                message_hex = ciphertext_with_key[end_index + len(end_marker):].strip()
                                message_base64 = ciphertext_with_key[end_index + len(end_marker):].strip()
                                message_hex = base64.b64decode(message_base64).hex()

                                # Convertir la clé et le message hexadécimaux en chaînes d'octets (bytes)
                                cle = bytes.fromhex(cle_hex)
                                message = bytes.fromhex(message_hex)
                                # Appeler la fonction decrypt() pour décrypter le message
                                plaintext = decryptaes(message, cle)

                                hashmessage = sha256_hash(plaintext)

                                cle_publique = tuple(map(int, champ_clepublique.get().split()))
                                cle_publiqueaff = (champ_clepublique.get)()

                                sha256dechiffre = decryptprivee(cle_sign, cle_publique)
                                if sha256dechiffre == hashmessage:
                                    if messagebox.askyesno("Signature verified",
                                                           "The author of this message is (SHA256): " + "\n   " + sha256_hash(
                                                               cle_publiqueaff) + "\n   " + "\nDo you want to see the full public key?"):
                                        # Annuler l'enregistrement
                                        messagebox.showinfo("Signature ",
                                                            "public key :" + cle_publiqueaff)
                                else:
                                    messagebox.showwarning("Invalid or missing signature",
                                                           "You can't be sure who wrote this message.")
                            except Exception as e:
                                messagebox.showwarning("Invalid or missing signature",
                                                       "You can't be sure who wrote this message.")
                                print("Erreur :", e)

                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, plaintext)

                        else:
                            message_base64 = champ_message.get('1.0', tk.END).strip()
                            message_hex = base64.b64decode(message_base64).hex()
                            message = bytes.fromhex(message_hex)

                            # Appeler la fonction decrypt() pour décrypter le message
                            plaintext = decryptaes(message, cle)
                            # Afficher le message décrypté
                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, plaintext)

                    elif type == 4:
                        ciphertext_with_key = champ_message.get('1.0', tk.END).strip()

                        begin_marker = "---BEGIN SIGN CRRO MESSAGE---"
                        start_marker = "---Start Signature---"
                        try:
                            # Trouver les indices des balises de début et de fin
                            start_index = ciphertext_with_key.index(begin_marker) + len(begin_marker)
                            end_index = ciphertext_with_key.index(start_marker)
                            message = ciphertext_with_key[start_index:end_index].strip()

                        except Exception as e:
                            messagebox.showwarning("Error",
                                                   "An error has occurred.")

                        cle_hex = champ_cle.get()

                        if sign == 1:
                            start_marker = "---Start Signature---"
                            end_marker = "---End Signature---"

                            try:
                                start_index = ciphertext_with_key.index(start_marker) + len(start_marker)
                                end_index = ciphertext_with_key.index(end_marker)
                                cle_sign = ciphertext_with_key[start_index:end_index].strip()
                                cle_sign = cle_sign.replace(" ", "").replace("\n", "")
                                cle_sign = cle_sign.split()
                                cle_publique = tuple(map(int, champ_clepublique.get().split()))
                                cle_publiqueaff = (champ_clepublique.get)()
                                hashmessage = sha256_hash(message)
                                sha256dechiffre = decryptprivee(cle_sign, cle_publique)

                                if sha256dechiffre == hashmessage:
                                    if messagebox.askyesno("Signature verified",
                                                           "The author of this message is (SHA256): " + "\n   " + sha256_hash(
                                                               cle_publiqueaff) + "\n   " + "\nDo you want to see the full public key?"):
                                        # Annuler l'enregistrement
                                        messagebox.showinfo("Signature ",
                                                            "Public key :" + cle_publiqueaff)
                                else:
                                    messagebox.showwarning("Invalid or missing signature",
                                                           "You cannot be sure who wrote this message.")

                            except Exception as e:
                                messagebox.showwarning("Invalid or missing signature",
                                                       "You cannot be sure who wrote this message.")
                                print("Erreur :", e)

                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, message)

                    if type == 5:

                        # Extraire la clé et le message chiffré
                        start_marker = "---BEGIN CURVE INT---"
                        end_marker = "---END CURVE INT---"
                        if start_marker not in ciphertext_with_key or end_marker not in ciphertext_with_key:
                            messagebox.showerror("Error",
                                                 "Missing CRUVE INT key in ciphertext, or missing private key.")
                            return

                        start_index = ciphertext_with_key.index(start_marker) + len(start_marker)
                        end_index = ciphertext_with_key.index(end_marker)
                        cle_hex = ciphertext_with_key[start_index:end_index].strip()
                        random_int_on_curve = cle_hex.replace(" ", "").replace("\n", "")

                        random_int_on_curve = base64.b64decode(random_int_on_curve).decode()

                        random_int_on_curve = random_int_on_curve.replace(" ", "").replace("(", "").replace(")",
                                                                                                            "").split(
                            ",")

                        random_int_on_curve = tuple(
                            int(random_int_on_curve) for random_int_on_curve in random_int_on_curve)

                        message_hex = ciphertext_with_key[end_index + len(end_marker):].strip()
                        message_hex = message_hex.replace(" ", "").replace("\n", "")

                        encrypted_message = ciphertext_with_key[end_index + len(end_marker):].strip()
                        # message_hex = base64.b64decode(message_base64).hex()

                        private_key = int(champ_clepriver.get())

                        encrypted_message.encode('utf-8')

                        message = decrypt_message(private_key, random_int_on_curve, encrypted_message)

                        if sign == 1:

                            message = message.decode('utf-8')

                            gx, gy = champ_clepublique.get().split()

                            public_key = int(gx), int(gy)

                            public_keyaff = str(public_key)

                            start_marker = "---Start Signature---"
                            end_marker = "---End Signature---"

                            start_index = ciphertext_with_key.index(start_marker) + len(start_marker)
                            end_index = ciphertext_with_key.index(end_marker)
                            cle_sign = ciphertext_with_key[start_index:end_index].strip()
                            cle_sign = cle_sign.replace(" ", "").replace("\n", "")

                            signature = base64.b64decode(cle_sign).decode('utf-8').replace(" ", "")

                            signature = signature.replace(" ", "").replace("(", "").replace(")", "").split(",")

                            signature = tuple(int(signature) for signature in signature)

                            x, i = verification_signature(public_key, signature, message)

                            if x == i:
                                if messagebox.askyesno("Signature verified",
                                                       "The author of this message is (SHA256) : " + "\n   " + sha256_hash(
                                                           public_keyaff.replace(",", "").replace("(", "").replace(")",
                                                                                                                   "")) + "\n   " + "\nDo you want to see the full public key?"):
                                    # Annuler l'enregistrement
                                    messagebox.showinfo("Signature ",
                                                        "public key :\n" + public_keyaff)
                            else:
                                messagebox.showwarning("Invalid or missing signature",
                                                       "You can't be sure who wrote this message.")

                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, message)





                        else:

                            champ_message.delete('1.0', tk.END)
                            champ_message.insert(tk.END, message)

                fenetre.after(1, root.destroy)

            threading.Thread(target=decrypteraes_thread).start()

        bar_de_chargement()


def generate_and_display_aes_key():
    key = generate_aes_key()
    champ_cle.delete(0, tk.END)
    champ_cle.insert(0, key.hex())


def copieraes(texte):
    fenetre.clipboard_clear()
    fenetre.clipboard_append(texte)


def export_key_paire():
    global export_key
    export_key = 3
    open_key_access_window()


def export_key_pu():
    global export_key
    export_key = 2
    open_key_access_window()


def export_key_pr():
    global export_key
    export_key = 1
    open_key_access_window()


def open_key_access_window():
    global key_access_window
    global chiffrage
    if key_access_window is not None:
        key_access_window.deiconify()
        return

    key_access_window = tk.Toplevel(fenetre)
    key_access_window.title("Access Key Pair")

    new_window_width = 350
    new_window_height = 125

    x = fenetre.winfo_x() + (fenetre.winfo_width() - new_window_width) // 2
    y = fenetre.winfo_y() + (fenetre.winfo_height() - new_window_height) // 2

    key_access_window.geometry(f"{new_window_width}x{new_window_height}+{x}+{y}")

    def on_key_access_window_close():
        global key_access_window
        key_access_window.destroy()
        key_access_window = None

    key_access_window.protocol("WM_DELETE_WINDOW", on_key_access_window_close)

    label_nom = ttk.Label(key_access_window, text="Name:", font=("Helvetica", 12))
    label_nom.grid(padx=120)
    champ_nom = ttk.Entry(key_access_window, width=50)
    champ_nom.grid()

    label_password = ttk.Label(key_access_window, text="Password:", font=("Helvetica", 12))
    label_password.grid(padx=120)
    champ_password = ttk.Entry(key_access_window, width=50, show="*")
    champ_password.grid()

    def access_key_pair3(event=None):
        global chiffrage
        global export_key

        if chiffrage == True:

            password = champ_password.get().strip()

            # Conversion du mot de passe en une clé de 32 octets
            key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)

            # Encodage de la clé en base64
            encoded_key = base64.urlsafe_b64encode(key)

            # Création de l'objet Fernet avec la clé encodée
            cipher_suite = Fernet(encoded_key)

            with open("gestion_avancé.txt", "r") as file:
                stored_key_pair = file.read().strip().split('\n')

                # Décryptage de la paire de clés avec la clé
                decrypted_public_key = cipher_suite.decrypt(stored_key_pair[0].split(': ')[1].encode('utf-8')).decode(
                    'utf-8')
                decrypted_private_key = cipher_suite.decrypt(stored_key_pair[1].split(': ')[1].encode('utf-8')).decode(
                    'utf-8')

                champ_clepriver.delete(0, tk.END)

                champ_clepriver.insert(tk.END, decrypted_private_key)

                messagebox.showinfo("Access Granted", "Access to the key pair authorized.")

            on_key_access_window_close()

        else:
            password = champ_password.get().strip()

            # Hachage du mot de passe avec SHA-256
            password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()

            # Double hachage du hash du mot de passe avec SHA-256
            double_hash = "Nom: " + champ_nom.get().strip()

            # Lecture du fichier texte pour trouver la paire de clés chiffrées correspondante
            with open("key_pairs.txt", "r") as file:
                lines = file.readlines()
                found = False
                for i in range(0, len(lines), 5):  # Increment range by 5 since each pair occupies 5 lines
                    if lines[i].strip() == double_hash:
                        encrypted_public_key = lines[i + 3].strip().split(": ")[1]
                        encrypted_private_key = lines[i + 4].strip().split(": ")[1]

                        # Déchiffrement des clés avec le mot de passe
                        key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)
                        encoded_key = base64.urlsafe_b64encode(key)
                        cipher_suite = Fernet(encoded_key)

                        public_key = cipher_suite.decrypt(encrypted_public_key.encode('utf-8')).decode('utf-8')
                        private_key = cipher_suite.decrypt(encrypted_private_key.encode('utf-8')).decode('utf-8')
                        bureau = os.path.expanduser("~/Desktop")

                        if export_key == 3:
                            with open(os.path.join(bureau, "Export_key_pair.key"), "a") as file:

                                file.write(f"Public Key: {public_key}\n")
                                file.write(f"Private Key: {private_key}\n")
                                messagebox.showinfo("Saved", "The public key has been successfully saved.")
                        elif export_key == 2:
                            with open(os.path.join(bureau, "Export_public_key.key"), "a") as file:

                                file.write(f"Public Key: {public_key}\n")
                                messagebox.showinfo("Saved", "The public key has been successfully saved.")

                        elif export_key == 1:
                            with open(os.path.join(bureau, "Export_private_key.key"), "a") as file:

                                file.write(f"Private Key: {private_key}\n")

                            messagebox.showinfo("Sauvegarde", "The private key has been successfully saved.")
                        else:
                            messagebox.showerror("Error", "Please fill in all the fields.")

                        found = True
                        refresh_sha256()
                        break

                if not found:
                    messagebox.showerror("Access denied", "Incorrect password.")

            on_key_access_window_close()

    # Associer la touche "Entrée" à la fonction access_key_pair3
    champ_password.bind("<Return>", access_key_pair3)

    # Ajouter le bouton "Accéder" s'il n'est pas déjà présent dans la fenêtre
    bouton_access = ttk.Button(key_access_window, text="Access", command=access_key_pair3)
    bouton_access.grid()


acces_key = 0


def acces_key_paire():
    global acces_key
    acces_key = 3
    open_key_access_window2()


def access_key_pu():
    global acces_key
    acces_key = 2
    open_key_access_window2()


def acces_key_pr():
    global acces_key
    acces_key = 1
    open_key_access_window2()


def open_key_access_window2():
    global key_access_window
    global chiffrage
    if key_access_window is not None:
        key_access_window.deiconify()
        return

    key_access_window = tk.Toplevel(fenetre)
    key_access_window.title("Access to the key pair")

    new_window_width = 350
    new_window_height = 125

    x = fenetre.winfo_x() + (fenetre.winfo_width() - new_window_width) // 2
    y = fenetre.winfo_y() + (fenetre.winfo_height() - new_window_height) // 2

    key_access_window.geometry(f"{new_window_width}x{new_window_height}+{x}+{y}")

    def on_key_access_window_close():
        global key_access_window
        key_access_window.destroy()
        key_access_window = None

    key_access_window.protocol("WM_DELETE_WINDOW", on_key_access_window_close)

    label_nom = ttk.Label(key_access_window, text="Name:", font=("Helvetica", 12))
    label_nom.grid(padx=120)
    champ_nom = ttk.Entry(key_access_window, width=50)
    champ_nom.grid()

    label_password = ttk.Label(key_access_window, text="Password:", font=("Helvetica", 12))
    label_password.grid(padx=120)
    champ_password = ttk.Entry(key_access_window, width=50, show="*")
    champ_password.grid()

    def access_key_pair3(event=None):
        global chiffrage
        global acces_key
        if chiffrage == True:

            password = champ_password.get().strip()

            # Conversion du mot de passe en une clé de 32 octets
            key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)

            # Encodage de la clé en base64
            encoded_key = base64.urlsafe_b64encode(key)

            # Création de l'objet Fernet avec la clé encodée
            cipher_suite = Fernet(encoded_key)

            with open("gestion_avancé.txt", "r") as file:
                stored_key_pair = file.read().strip().split('\n')

                # Décryptage de la paire de clés avec la clé
                decrypted_public_key = cipher_suite.decrypt(stored_key_pair[0].split(': ')[1].encode('utf-8')).decode(
                    'utf-8')
                decrypted_private_key = cipher_suite.decrypt(stored_key_pair[1].split(': ')[1].encode('utf-8')).decode(
                    'utf-8')

                champ_clepriver.delete(0, tk.END)

                champ_clepriver.insert(tk.END, decrypted_private_key)

                messagebox.showinfo("Access granted", "Access to key pair granted.")

            on_key_access_window_close()

        else:
            password = champ_password.get().strip()

            # Hachage du mot de passe avec SHA-256
            password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()

            # Double hachage du hash du mot de passe avec SHA-256
            double_hash = "Nom: " + champ_nom.get().strip()

            # Lecture du fichier texte pour trouver la paire de clés chiffrées correspondante
            with open("key_pairs.txt", "r") as file:
                lines = file.readlines()
                found = False
                for i in range(0, len(lines), 5):  # Increment range by 5 since each pair occupies 5 lines
                    if lines[i].strip() == double_hash:
                        encrypted_public_key = lines[i + 3].strip().split(": ")[1]
                        encrypted_private_key = lines[i + 4].strip().split(": ")[1]

                        # Déchiffrement des clés avec le mot de passe
                        key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)
                        encoded_key = base64.urlsafe_b64encode(key)
                        cipher_suite = Fernet(encoded_key)

                        public_key = cipher_suite.decrypt(encrypted_public_key.encode('utf-8')).decode('utf-8')
                        private_key = cipher_suite.decrypt(encrypted_private_key.encode('utf-8')).decode('utf-8')

                        if acces_key == 3:
                            champ_clepriver.delete(0, tk.END)
                            champ_clepriver.insert(tk.END, private_key)
                            champ_clepublique.delete(0, tk.END)
                            champ_clepublique.insert(tk.END, public_key)
                        elif acces_key == 2:
                            champ_clepublique.delete(0, tk.END)
                            champ_clepublique.insert(tk.END, public_key)
                        elif acces_key == 1:
                            champ_clepriver.delete(0, tk.END)
                            champ_clepriver.insert(tk.END, private_key)

                        line = champ_nom.get().strip()

                        found = True
                        refresh_sha256()
                        break

                if not found:
                    messagebox.showerror("Access denied", "Invalid password.")

            on_key_access_window_close()

    # Associer la touche "Entrée" à la fonction access_key_pair3
    champ_password.bind("<Return>", access_key_pair3)

    # Ajouter le bouton "Accéder" s'il n'est pas déjà présent dans la fenêtre
    bouton_access = ttk.Button(key_access_window, text="Access", command=access_key_pair3)
    bouton_access.grid()


def open_key_access_window3(line):
    global key_access_window
    global chiffrage
    if key_access_window is not None:
        key_access_window.deiconify()
        return

    key_access_window = tk.Toplevel(fenetre)
    key_access_window.title("Access to the key pair")

    new_window_width = 350
    new_window_height = 125

    x = fenetre.winfo_x() + (fenetre.winfo_width() - new_window_width) // 2
    y = fenetre.winfo_y() + (fenetre.winfo_height() - new_window_height) // 2

    key_access_window.geometry(f"{new_window_width}x{new_window_height}+{x}+{y}")

    def on_key_access_window_close():
        global key_access_window
        key_access_window.destroy()
        key_access_window = None

    key_access_window.protocol("WM_DELETE_WINDOW", on_key_access_window_close)

    label_nom = ttk.Label(key_access_window, text="Name:", font=("Helvetica", 12))
    label_nom.grid(padx=120)
    champ_nom = ttk.Entry(key_access_window, width=50)
    champ_nom.grid()

    champ_nom.delete(0, tk.END)
    champ_nom.insert(tk.END, line.strip())

    label_password = ttk.Label(key_access_window, text="Password:", font=("Helvetica", 12))
    label_password.grid(padx=120)
    champ_password = ttk.Entry(key_access_window, width=50, show="*")
    champ_password.grid()
    champ_password.focus_set()

    def access_key_pair3(event=None):
        global chiffrage
        if chiffrage == True:

            password = champ_password.get().strip()

            # Conversion du mot de passe en une clé de 32 octets
            key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)

            # Encodage de la clé en base64
            encoded_key = base64.urlsafe_b64encode(key)

            # Création de l'objet Fernet avec la clé encodée
            cipher_suite = Fernet(encoded_key)

            with open("gestion_avancé.txt", "r") as file:
                stored_key_pair = file.read().strip().split('\n')

                # Décryptage de la paire de clés avec la clé
                decrypted_public_key = cipher_suite.decrypt(stored_key_pair[0].split(': ')[1].encode('utf-8')).decode(
                    'utf-8')
                decrypted_private_key = cipher_suite.decrypt(stored_key_pair[1].split(': ')[1].encode('utf-8')).decode(
                    'utf-8')

                champ_clepriver.delete(0, tk.END)

                champ_clepriver.insert(tk.END, decrypted_private_key)

                messagebox.showinfo("Access granted", "Access to key pair granted.")

            on_key_access_window_close()

        else:
            password = champ_password.get().strip()

            # Hachage du mot de passe avec SHA-256
            password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()

            # Double hachage du hash du mot de passe avec SHA-256
            double_hash = "Nom: " + champ_nom.get().strip()

            # Lecture du fichier texte pour trouver la paire de clés chiffrées correspondante
            with open("key_pairs.txt", "r") as file:
                lines = file.readlines()
                found = False
                for i in range(0, len(lines), 5):  # Increment range by 5 since each pair occupies 5 lines
                    if lines[i].strip() == double_hash:
                        encrypted_public_key = lines[i + 3].strip().split(": ")[1]
                        encrypted_private_key = lines[i + 4].strip().split(": ")[1]

                        # Déchiffrement des clés avec le mot de passe
                        key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), b'salt', 100000)
                        encoded_key = base64.urlsafe_b64encode(key)
                        cipher_suite = Fernet(encoded_key)

                        public_key = cipher_suite.decrypt(encrypted_public_key.encode('utf-8')).decode('utf-8')
                        private_key = cipher_suite.decrypt(encrypted_private_key.encode('utf-8')).decode('utf-8')

                        champ_clepriver.delete(0, tk.END)

                        champ_clepriver.insert(tk.END, private_key)

                        messagebox.showinfo("Access authorized", "Access to the key pair authorized.")
                        found = True
                        refresh_sha256()
                        break

                if not found:
                    messagebox.showerror("Access denied", "Invalid password.")

            on_key_access_window_close()

    # Associer la touche "Entrée" à la fonction access_key_pair3
    champ_password.bind("<Return>", access_key_pair3)

    # Ajouter le bouton "Accéder" s'il n'est pas déjà présent dans la fenêtre
    bouton_access = ttk.Button(key_access_window, text="access", command=access_key_pair3)
    bouton_access.grid()


def ouvrir_site():
    # Afficher une boîte de dialogue demandant à l'utilisateur s'il veut accéder au site
    response = messagebox.askyesno("Confirmation", "Do you want to go to the site ?")

    if response:
        # Ouvrir le site dans un navigateur
        import webbrowser
        webbrowser.open("http://crro.neocities.org")


def ouvrir_github():
    # Afficher une boîte de dialogue demandant à l'utilisateur s'il veut accéder au site
    response = messagebox.askyesno("Confirmation", "Do you want to go to Github ?")

    if response:
        # Ouvrir le site dans un navigateur
        import webbrowser
        webbrowser.open("https://github.com/Elg256/CRRO")


def ouvrir_documentation():
    # Ouvrir le fichier "documentation.pdf" dans le lecteur de PDF par défaut
    try:
        import webbrowser
        webbrowser.open("documentation.pdf")
    except Exception as e:
        messagebox.showerror("Error", "Failed to open documentation : {}".format(e))


def ouvrir_version():
    version = tk.Toplevel(fenetre)
    version.title("About")


    # Vérifier si le fichier d'image existe
    image_path = "logo.png"
    if os.path.exists(image_path):
        try:
            # Créer un objet PhotoImage pour l'image
            logo_image = tk.PhotoImage(file=image_path)

            # Redimensionner l'image (par exemple, diviser par 2 pour la réduire de moitié)
            resized_image = logo_image.subsample(5, 5)

            # Créer un label pour afficher l'image redimensionnée
            label_image = tk.Label(version, image=resized_image)
            label_image.pack(pady=5, padx=5)

            # Il est important de garder une référence à l'objet PhotoImage pour éviter que l'image ne soit supprimée par le garbage collector
            label_image.image = resized_image
        except tk.TclError as e:
            # En cas d'erreur, afficher un message d'erreur
            print("Error loading image :", e)
    else:
        print("Image file not found :", image_path)

    label_version = tk.Label(version, text="Versions:", font=("Helvetica", 12))
    label_version.pack(pady=5, padx=5)
    label_version = tk.Label(version, text="Application : CRRO 2.9.3 ", font=("Helvetica", 12))
    label_version.pack(pady=2, padx=5)
    label_version = tk.Label(version, text="Protocols:",
                             font=("Helvetica", 12))
    label_version.pack(pady=5, padx=5)
    label_version = tk.Label(version, text="Text encryption: ERA 2.5.5", font=("Helvetica", 12))
    label_version.pack(pady=2, padx=5)
    label_version = tk.Label(version, text="File encryption: FEA 1.3",
                             font=("Helvetica", 12))
    label_version.pack(pady=2, padx=5)
    label_version = tk.Label(version, text="Release date : 22/02/2024", font=("Helvetica", 12))
    label_version.pack(pady=5, padx=10)


def refresh_sha256(event=None):
    cle_publique = (champ_clepublique.get)()
    cle_publique = sha256_hash(cle_publique)
    sha256.set(cle_publique)


def paracle_visible2():
    global cle_visible
    global viscle2
    global cle_visible2
    if champ_clepriver.winfo_ismapped():
        champ_clepriver.grid_forget()
        label_clepriver.grid_forget()
        cle_visible2 = 2

    else:
        label_clepriver.grid(row=0, column=5)
        champ_clepriver.grid(row=1, column=5, padx=10)  # Affiche le champ de texte
        cle_visible2 = 1
    fenetre.update_idletasks()


def paracle_visible():
    global cle_visible
    global viscle
    global cle_visible2

    if champ_cle.winfo_ismapped():
        bouton_generer_cle_aes.grid_forget()
        champ_cle.grid_forget()
        label_cle.grid_forget()
        cle_visible = 2

    else:

        label_cle.grid(row=0, column=6)
        champ_cle.grid(row=1, column=6, padx=10)
        bouton_generer_cle_aes.grid(row=2, column=6)
        cle_visible = 1
    fenetre.update_idletasks()


def toggle_checkbox():
    global sign
    global sign2
    if checkbox_var.get() == 1:

        sign = 1
        sign2.set("Enable")
        label_typechiffrage2.config(text=sign2.get())
    else:
        sign = 2
        sign2.set("Disable")
        label_typechiffrage2.config(text=sign2.get())


def toggle_checkbox1():
    global sign
    global sign2
    global type
    global chiffrage
    global type2
    if checkbox_var1.get() == 1:

        type = 1
        chiffrage = 2
        type2.set("AES+RSA")
        label_typechiffrage2.config(text=type2.get())
    else:

        type = 4
        chiffrage = 2
        type2.set("no encryption")
        label_typechiffrage2.config(text=type2.get())


fenetre = tk.Tk()
# getting screen's height in mm
global height
global width
height = fenetre.winfo_screenmmheight() - 235

# getting screen's width in mm
width = fenetre.winfo_screenmmwidth() - 100

charger_parametres()
type2 = tk.StringVar()
sign2 = tk.StringVar()


def setaffiche():
    if chiffrage == 2:
        if type == 1:
            type2.set("AES+RSA")
        elif type == 2:
            type2.set("RSA")
        elif type == 3:
            type2.set("AES")
        elif type == 4:
            type2.set("no encryption")
        elif type == 5:
            type2.set("ecies")
    elif chiffrage == 1:
        type2.set("Advanced")


def setaffiche2():
    if sign == 2:
        sign2.set("Disable")
    if sign == 1:
        sign2.set("Enable")


def toggle_key_visibility2():
    global cle_visible2

    if cle_visible2 == 2:
        champ_clepriver.grid_forget()
        label_clepriver.grid_forget()


def toggle_key_visibility():
    global cle_visible

    if cle_visible == 2:
        bouton_generer_cle_aes.grid_forget()
        champ_cle.grid_forget()
        label_cle.grid_forget()


setaffiche()
setaffiche2()

fenetre.title("CRRO")

w, h = (fenetre.winfo_screenwidth(), fenetre.winfo_screenheight(),)

fenetre.geometry("%dx%d" % (w, h))


menubar = tk.Menu(fenetre)
fenetre.config(menu=menubar)


def fermer_fenetre():
    enregistrer_parametres()


def on_fenetre_close():
    # Appeler la fonction pour enregistrer les paramètres
    enregistrer_parametres()


# Définir le comportement lors de la fermeture de la fenêtre principale
fenetre.protocol("WM_DELETE_WINDOW", on_fenetre_close)

private_key_image = PhotoImage(file="private_key_menu.png")

lock_image = PhotoImage(file="lock_menu.png")
lock_open_image = PhotoImage(file="lock_open_menu.png")
smartcard_image = PhotoImage(file="smartcard_menu.png")
exit_image = PhotoImage(file="exit.png")
copy_image = PhotoImage(file="copy.png")
import_image = PhotoImage(file="import_key.png")
export_image = PhotoImage(file="export_key.png")
image_file_decrypt = PhotoImage(file="file_decrypt.png")
register_image = PhotoImage(file="registre.png")
sign_image = PhotoImage(file="sign.png")
show_image = PhotoImage(file="eyes.png")
block_lenght_image = PhotoImage(file="block_lenght.png")
encryption_type_image = PhotoImage(file="puzzle.png")

# Création du menu "Fichier"
file_menu = tk.Menu(menubar, tearoff=False)
menubar.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="New Key Pair", command=open_key_management_window, image=private_key_image, compound=LEFT)
file_menu.add_command(label="Import Key Pair", command=import_keypair, image=import_image, compound=LEFT)
file_menu.add_separator()

menu_access = Menu(file_menu, tearoff=0)
menu_access.add_command(label="Access Public Keys", command=access_key_pu)
menu_access.add_command(label="Access Private Keys", command=acces_key_pr)
menu_access.add_command(label="Access Key Pairs", command=acces_key_paire)
file_menu.add_cascade(label="Access Keys", underline=0, menu=menu_access, image=private_key_image, compound=LEFT)

menu_recent = Menu(file_menu, tearoff=0)
menu_recent.add_command(label="Export Public Key", command=export_key_pu)
menu_recent.add_command(label="Export Private Key", command=export_key_pr)
menu_recent.add_command(label="Export Key Pair", command=export_key_paire)
file_menu.add_cascade(label="Export Keys", underline=0, menu=menu_recent, image=export_image, compound=LEFT)

file_menu.add_command(label="Encrypt/Decrypt Files", command=ouvrir_file, image=image_file_decrypt, compound=LEFT)
file_menu.add_command(label="Copy Notepad", command=copy_result, image=copy_image, compound=LEFT)

file_menu.add_separator()
file_menu.add_command(label="Exit", command=fermer_fenetre, image=exit_image, compound=LEFT)

# Create the "Encryption" menu
encrypt_menu = tk.Menu(menubar, tearoff=False)
menubar.add_cascade(label="Encryption", menu=encrypt_menu)
encrypt_menu.add_command(label="Encrypt Notepad", command=crypteraes, image=lock_image, compound=LEFT)
encrypt_menu.add_command(label="Decrypt Notepad", command=decrypteraes, image=lock_open_image, compound=LEFT)
encrypt_menu.add_command(label="Encrypt/Decrypt Files", command=ouvrir_file, image=image_file_decrypt, compound=LEFT)
encrypt_menu.add_command(label="Encryption Type", command=ouvrir_type_chiffrage, image=encryption_type_image,
                         compound=LEFT)

key_menu = tk.Menu(menubar, tearoff=False)
menubar.add_cascade(label="Key Management", menu=key_menu)
key_menu.add_command(label="New Key Pair", command=open_key_management_window, image=private_key_image, compound=LEFT)
key_menu.add_command(label="Import Key Pair", command=import_keypair, image=import_image, compound=LEFT)
key_menu.add_command(label="Register Public Key", command=ouvrir_deuxieme_fenetre, image=register_image, compound=LEFT)

menu_access = Menu(key_menu, tearoff=0)
menu_access.add_command(label="Access Public Keys", command=access_key_pu)
menu_access.add_command(label="Access Private Keys", command=acces_key_pr)
menu_access.add_command(label="Access Key Pairs", command=acces_key_paire)
key_menu.add_cascade(label="Access Keys", underline=0, menu=menu_access, image=private_key_image, compound=LEFT)

menu_recent = Menu(key_menu, tearoff=0)
menu_recent.add_command(label="Export Public Key", command=export_key_pu)
menu_recent.add_command(label="Export Private Key", command=export_key_pr)
menu_recent.add_command(label="Export Key Pair", command=export_key_paire)

key_menu.add_cascade(label="Export Keys", underline=0, menu=menu_recent, image=export_image, compound=LEFT)
key_menu.add_command(label="RSA Key lenght", command=ouvrir_parametres2, image=private_key_image, compound=LEFT)
# i put the Refresh all certificats after the function for it because i don't know how to code clean, sorry :)

smartcard_menu = tk.Menu(menubar, tearoff=False)
menubar.add_cascade(label="Smartcard", menu=smartcard_menu)
smartcard_menu.add_command(label="Use Smartcard", command=utiliser_smartcard, image=smartcard_image, compound=LEFT)
smartcard_menu.add_command(label="Create Smartcard", command=creer_smartcard, image=smartcard_image, compound=LEFT)

parameters_menu = tk.Menu(menubar, tearoff=False)
menubar.add_cascade(label="Parameters", menu=parameters_menu)
parameters_menu.add_command(label="Show/Hide AES Key", command=paracle_visible, image=show_image, compound=LEFT)
parameters_menu.add_command(label="Show/Hide Private Key", command=paracle_visible2, image=show_image, compound=LEFT)
parameters_menu.add_command(label="RSA Key lenght", command=ouvrir_parametres2, image=private_key_image, compound=LEFT)
parameters_menu.add_command(label="RSA Block Length", command=ouvrir_parametres_rsa, image=block_lenght_image,
                            compound=LEFT)
parameters_menu.add_command(label="Toggle Signature", command=type_signature, image=sign_image, compound=LEFT)
parameters_menu.add_command(label="Encryption Type", command=ouvrir_type_chiffrage, image=encryption_type_image,
                            compound=LEFT)





real_money_image = PhotoImage(file="real_money.png")
logo_elg256 = PhotoImage(file="logo_elg256.png")
logo_crro = PhotoImage(file="logo_crro.png")

about_menu = tk.Menu(menubar, tearoff=False)
menubar.add_cascade(label="About", menu=about_menu)
about_menu.add_command(label="Version: 2.9.2", command=ouvrir_version)
about_menu.add_command(label="Our Website: crro.neocities.org", command=ouvrir_site, image=logo_crro, compound=LEFT)
about_menu.add_command(label="Our Github: github.com/Elg256/CRRO", command=ouvrir_github, image=logo_elg256,
                       compound=LEFT)
about_menu.add_command(label="Documentation", command=ouvrir_documentation, image=copy_image, compound=LEFT)
about_menu.add_command(label="Support Us", command=adressebtc, image=real_money_image, compound=LEFT)

frame = tk.Frame(fenetre)
frame.grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)


frame.columnconfigure(3, weight=2)
frame.rowconfigure(3,weight=2)

image_lock = PhotoImage(file="lock.png")

bouton_crypter = ttk.Button(frame, text="Encrypt", image=image_lock, compound=LEFT, width=10, command=crypteraes)
bouton_crypter.grid(row=0, column=0, padx=2.5, ipady=12)

image_lock_open = PhotoImage(file="lock_open.png")

bouton_crypter = ttk.Button(frame, text="Decrypt", image=image_lock_open, compound=LEFT, width=10, command=decrypteraes)
bouton_crypter.grid(row=0, column=1, padx=10, sticky="ne", ipady=12)

label_typechiffrage = ttk.Label(frame, text="Encryption Type:", font=("Helvetica", 8))
label_typechiffrage.grid(row=1, column=0, padx=1)
label_typechiffrage2 = ttk.Label(frame, textvariable=type2)
label_typechiffrage2.grid(row=2, column=0, padx=1)

label_signature = ttk.Label(frame, text="Signature:", font=("Helvetica", 8))
label_signature.grid(row=1, column=1, padx=1)
label_signature2 = ttk.Label(frame, textvariable=sign2)
label_signature2.grid(row=2, column=1, padx=1)

label_clepublique = ttk.Label(frame, text="Public Key:", font=("Helvetica", 12))
label_clepublique.grid(row=0, column=3, padx=10)
champ_clepublique = ttk.Entry(frame, width=60)
champ_clepublique.grid(row=1, column=3, padx=10)
champ_clepublique.bind('<KeyRelease>', refresh_sha256)

label_sign2 = ttk.Label(frame, text="SHA256:")
label_sign2.grid(row=2, column=3, padx=0)
# Create the variable StringVar to store the result SHA-256 (sign2)
sha256 = tk.StringVar()
label_sign2_result = ttk.Label(frame, textvariable=sha256)
label_sign2_result.grid(row=3, column=3, padx=0)
sha256.set("None")


def copy():
    content = champ_message.get("sel.first", "sel.last")
    fenetre.clipboard_clear()
    fenetre.clipboard_append(content)


def cut():
    content = champ_message.get("sel.first", "sel.last")
    fenetre.clipboard_clear()
    fenetre.clipboard_append(content)
    champ_message.delete("sel.first", "sel.last")


def paste():
    content = fenetre.clipboard_get()
    champ_message.insert("insert", content)


def undo():
    champ_message.edit_undo()


def undo_bouton():
    global type
    if type == 1:
        tychi = 7
    elif type == 2:
        tychi = 5
    elif type == 3:
        tychi = 3
    elif type == 4:
        tychi = 3

    for i in range(1, tychi):
        champ_message.edit_undo()


popup_menu = tk.Menu(fenetre, tearoff=0)
popup_menu.add_command(label="Copy", command=copy)
popup_menu.add_command(label="Cut", command=cut)
popup_menu.add_command(label="Paste", command=paste)
popup_menu.add_separator()
popup_menu.add_command(label="Undo", command=undo)


def copier_cle1(line, certificats_fenetre):
    certificats_fenetre.destroy()
    open_key_access_window3(line)


def copier_cle2(line):
    open_key_access_window3(line)


def liste_certificat():
    global certificats_fenetre
    if certificats_fenetre is not None and certificats_fenetre.winfo_exists():
        certificats_fenetre.deiconify()
        return
    certificats_fenetre = tk.Toplevel(fenetre)

    certificats_fenetre.title("Certificate Management")

    frame_ajout = tk.Frame(certificats_fenetre)
    frame_ajout.grid(pady=10)

    frame_cle = tk.Frame(certificats_fenetre, pady=5)
    frame_cle.grid(column=1, padx=10, pady=2)

    nom = tk.Label(certificats_fenetre, text="Name:")
    nom.grid(row=0, column=0, padx=10, sticky="W")

    type = tk.Label(certificats_fenetre, text="Type:")
    type.grid(row=0, column=0)

    with open("key_pairs.txt", "r") as fichier:
        contenu = fichier.readlines()
        i = 0  # Utilisé pour suivre la position actuelle dans le contenu
        for ligne in contenu:
            if ligne.startswith("Nom:"):
                nom = ligne.split(": ")[1].strip()
                typecleaff = contenu[i + 1].split(": ")[1].strip()  # Ligne suivante

                frame_cle = tk.Frame(certificats_fenetre)
                frame_cle.grid(column=0, padx=10, pady=2)

                # Créer la variable Tkinter StringVar pour stocker la valeur du nom
                nom_var = tk.StringVar()
                nom_var.set(nom)

                typecleaff_var = tk.StringVar()
                typecleaff_var.set(typecleaff)
                entry_nom_priv = tk.Entry(frame_cle, textvariable=nom_var, width=20,
                                          highlightbackground="gray", highlightcolor="gray", highlightthickness=1)
                entry_nom_priv.grid(row=0, column=0, padx=0, pady=0, sticky="w")

                entry_type = tk.Entry(frame_cle, textvariable=typecleaff_var, width=20
                                      ,highlightbackground="gray", highlightcolor="gray", highlightthickness=1)
                entry_type.grid(row=0, column=1, padx=0, pady=0, sticky="w")

                def copier_cle_callback(nom=nom):  # Utiliser l'argument par défaut
                    copier_cle1(nom, certificats_fenetre)  # Remplacer "" par la clé publique que vous voulez utiliser

                button_copier = ttk.Button(frame_cle, text="Use", command=copier_cle_callback)
                button_copier.grid(row=0, column=2, padx=5, pady=5, sticky="w")

                def supprimer_callback(frame=frame_cle, key=""):
                    confirmer_suppression(frame, key)

                button_supprimer = ttk.Button(frame_cle, text="Delete", command=supprimer_callback)
                button_supprimer.grid(row=0, column=3, padx=5, pady=5, sticky="w")

                # Passer à la ligne suivante après avoir traité le nom
                i += 1
            else:
                # Passer à la ligne suivante si la ligne ne commence pas par "Nom:"
                i += 1


certificats_fenetre = None


def update_scrollbar_visibility(event=None):
    num_visible_lines = champ_message.cget("height")
    num_total_lines = int(champ_message.index("end-1c").split('.')[0])
    if num_total_lines > num_visible_lines:
        scrollbar.pack(side="right", fill="y")
    else:
        scrollbar.pack_forget()


label_message = ttk.Label(frame, text="Notepad:", font=("Helvetica", 10))
label_message.grid(row=4, column=0)
champ_message = Text(fenetre, undo=True)
champ_message.config(bd=1, relief="solid", highlightbackground="light blue",
                     undo=True, highlightcolor="light blue")

scrollbar = ttk.Scrollbar(champ_message)
scrollbar.pack(side="right", fill="y")

scrollbar.config(command=champ_message.yview)

champ_message.config(yscrollcommand=scrollbar.set)

scrollbar.pack_forget()

champ_message.bind("<Key>", update_scrollbar_visibility)

# Configurer la deuxième ligne pour s'étirer en hauteur
fenetre.grid_rowconfigure(2, weight=1)

# Configurer la première colonne pour s'étirer en largeur
fenetre.grid_columnconfigure(0, weight=1)

espace_vide = ttk.Label(fenetre)
espace_vide.grid(row=6)

bouton_retour = ttk.Button(frame, text="Undo", command=undo_bouton, width=1)
bouton_retour.grid(row=4, column=1, padx=15)

label_destinataire = ttk.Label(frame, text="Management:", font=("Helvetica", 10))
label_destinataire.grid(row=4, column=0, pady=10, sticky="W", padx=5)

# frame3
frame3 = tk.Frame(fenetre, borderwidth=2, relief="solid")
frame3.grid(row=2, column=0, sticky="NEW")  # Utiliser 'NSEW' pour que le cadre s'étende dans toutes les directions

frame_chiffrer = tk.Frame(frame3)  # Créez un cadre pour regrouper le label et le bouton
frame_chiffrer.grid(sticky="W")

label_ch = tk.Label(frame3, text="Encrypt:", font=("Helvetica", 10))
label_ch.grid(row=0, column=0, pady=10, padx=5)

label_dech = tk.Label(frame3, text="Signature:", font=("Helvetica", 10))
label_dech.grid(row=1, column=0, pady=10, padx=5)

checkbox_var1 = tk.IntVar()
# Création de la case à cocher
checkbox1 = ttk.Checkbutton(frame3, variable=checkbox_var1, command=toggle_checkbox1)
checkbox1.grid(row=0, column=1, pady=10, padx=5)

if type != 4:
    checkbox_var1.set(1)

bouton_registre = tk.Label(frame3, text="Public key ", font=("Helvetica", 12))
bouton_registre.grid(sticky="W", row=5, column=2)  # Utilisez pack pour le bouton à droite

frame_chiffrer.grid(row=5, column=2, columnspan=2)

label_sign3 = tk.Label(frame3, text="SHA256:")
label_sign3.grid(row=6, padx=0, column=3)
# Créer la variable StringVar pour stocker le résultat SHA-256 (sign2)
sha2562 = tk.StringVar()
label_sign3_result = tk.Label(frame3, textvariable=sha256)
label_sign3_result.grid(row=7, padx=1, column=3)
sha2562.set("None")

ligneespace = tk.Label(frame3, text="  ")
ligneespace.grid(row=8, padx=0)

frame_signer = tk.Frame(frame3)  # Créez un cadre pour regrouper le label et le bouton
frame_signer.grid(sticky="W")

checkbox_var = tk.IntVar()
# Création de la case à cocher
checkbox = ttk.Checkbutton(frame3, variable=checkbox_var, command=toggle_checkbox)
checkbox.grid(row=1, column=1, pady=10, padx=5)

if sign == 1:
    checkbox_var.set(1)

bouton_signerpour = tk.Label(frame3, text="Private key ", font=("Helvetica", 12))

bouton_signerpour.grid(sticky="W", row=9, column=2)  # Utilisez pack pour le label à gauche

frame_cle_priver = tk.Frame(frame3)
frame_cle_priver.grid(row=9, column=4, padx=5)

label_clepriver = tk.Label(frame_cle_priver, text="Private key:", font=("Helvetica", 12))
label_clepriver.grid(row=8, column=4)

champ_clepriver = tk.Entry(frame_cle_priver, width=60)
champ_clepriver.grid(sticky="W", row=9, column=4)
champ_clepriver.config(highlightbackground="gray", highlightcolor="gray", highlightthickness=1)

frame_cle_aes = tk.Frame(frame3)
frame_cle_aes.grid(row=5, column=4, padx=5)

label_cle = tk.Label(frame_cle_aes, text="Clé aes (hexadécimal) : ", font=("Helvetica", 12))
label_cle.grid(row=4, column=4)

champ_cle = tk.Entry(frame_cle_aes, width=50, highlightthickness=1)
champ_cle.grid(row=5, column=4, padx=5)
champ_cle.config(highlightbackground="gray", highlightcolor="gray")
bouton_generer_cle_aes = ttk.Button(frame_cle_aes, text="Générer nouvelle clé AES 256 bits",
                                    command=generate_and_display_aes_key)
bouton_generer_cle_aes.grid(row=6, column=4)
key = generate_aes_key()

champ_cle.delete(0, tk.END)
champ_cle.insert(0, key.hex())

frame3.grid_forget()

# frame4

frame4 = tk.Frame(fenetre, borderwidth=2, relief="solid")
frame4.grid(row=2, column=0, sticky="NSEW")


file = open("key_pairs.txt", "a+")


def show_private_key_certificat():
    for widget in frame4.winfo_children():
        widget.destroy()

    nom = ttk.Label(frame4, text="Name:")
    nom.grid(row=0, column=1, padx=10,pady=5)

    typecle = ttk.Label(frame4, text="Type:")
    typecle.grid(row=0, column=2, pady=5)

    iden = ttk.Label(frame4, text="identifier (SHA256):")
    iden.grid(row=0, column=3, pady=5)

    with open("key_pairs.txt", "r") as fichier:
        contenu = fichier.readlines()
        i = 0  # Utilisé pour suivre la position actuelle dans le contenu
        entry_noms = []
        for ligne in contenu:
            if ligne.startswith("Nom:"):
                nom = ligne.split(": ")[1].strip()
                entry_noms.append(nom)
                typecleaff = contenu[i + 1].split(": ")[1].strip()  # Ligne suivante
                hashcle = contenu[i + 2].split(": ")[1].strip()

                frame_nom = tk.Frame(frame4, pady=0)
                frame_nom.grid(row=i + 1, column=1)

                frame_typ = tk.Frame(frame4, pady=0)
                frame_typ.grid(row=i + 1, column=2)

                frame_id = tk.Frame(frame4, pady=0)
                frame_id.grid(row=i + 1, column=3)

                frame_bou = tk.Frame(frame4, pady=0)
                frame_bou.grid(row=i + 1, column=7)

                # Créer la variable Tkinter StringVar pour stocker la valeur du nom
                nom_var = tk.StringVar()
                nom_var.set(nom)

                typecleaff_var = tk.StringVar()
                typecleaff_var.set(typecleaff)

                hashcle_var = tk.StringVar()
                hashcle_var.set(hashcle)

                label_vide = tk.Label(frame_nom, text=" ")
                label_vide.grid(row=i + 1, column=1, padx=3, pady=0, sticky="w")

                entry_nom = tk.Entry(frame_nom, textvariable=nom_var, width=20,highlightbackground="gray",
                                     highlightcolor="gray", highlightthickness=1)
                entry_nom.grid(row=i + 1, column=2, padx=0, pady=0, sticky="w")

                entry_type = tk.Entry(frame_typ, textvariable=typecleaff_var, width=20,highlightbackground="gray",
                                      highlightcolor="gray", highlightthickness=1)
                entry_type.grid(row=i + 1, column=3, padx=0, pady=0, sticky="w")

                entry_id = tk.Entry(frame_id, textvariable=hashcle_var, width=70,
                                    highlightbackground="gray", highlightcolor="gray", highlightthickness=1)
                entry_id.grid(row=i + 1, column=4, padx=0, pady=0, sticky="w")

                def copier_cle_callback(nom=nom):  # Utiliser l'argument par défaut
                    copier_cle2(nom)  # Remplacer "" par la clé publique que vous voulez utiliser

                button_copier = ttk.Button(frame_bou, text="Use", command=copier_cle_callback)
                button_copier.grid(row=i + 1, column=4, padx=5, pady=5, sticky="w")

                def supprimer_callback(nom, frame):
                    response = messagebox.askyesno("Confirmation", "Voulez-vous vraiment supprimer la clé privée ?")
                    if response:
                        with open("key_pairs.txt", "r") as fichier:
                            lignes = fichier.readlines()

                        with open("key_pairs.txt", "w") as fichier:
                            i = 0
                            while i < len(lignes):
                                ligne = lignes[i]
                                if ligne.startswith("Nom:") and ligne.split(": ")[1].strip() == nom:
                                    # Ignorer les trois lignes du certificat actuel
                                    i += 5
                                else:
                                    fichier.write(ligne)
                                    i += 1

                        # Mettre à jour l'affichage en supprimant les widgets correspondants
                        frame.grid_forget()

                def supprimer_callback_wrapper(nom, frame):
                    return lambda: supprimer_callback(nom, frame)

                button_supprimer = ttk.Button(frame_bou, text="Delete",
                                              command=supprimer_callback_wrapper(nom, frame_bou))
                button_supprimer.grid(row=i + 1, column=5, padx=5, pady=5, sticky="w")

                # Passer à la ligne suivante après avoir traité le nom
                i += 1
            else:
                # Passer à la ligne suivante si la ligne ne commence pas par "Nom:"
                i += 1
    return entry_noms


entry_noms = show_private_key_certificat()

key_menu.add_command(label="Refresh all Certificats", command=lambda: show_private_key_certificat(),
                     image=register_image, compound=LEFT)


def on_name_selected_menu1(event):
    selected_name = combobox.get()

    line = selected_name
    open_key_access_window3(line)


combobox = ttk.Combobox(frame3, values=entry_noms, width=60)
combobox.grid(sticky="W", row=9, column=3, padx=10, pady=10)
combobox.bind("<<ComboboxSelected>>", on_name_selected_menu1)

file = open("registre.txt", "a+")

with open("registre.txt", "r") as fichier:
    contenu = fichier.readlines()
    i = 0  # Utilisé pour suivre la position actuelle dans le contenu
    entry_noms_pu = []
    while i < len(contenu):
        if contenu[i].startswith("Nom:"):
            nom = contenu[i].split(": ")[1].strip()  # Obtenir le nom correctement
            entry_noms_pu.append(nom)

            if i + 1 < len(contenu) and contenu[i + 1].startswith("Cle publique:"):
                publique = contenu[i + 1].split(": ")[1].strip()  # Obtenir la clé publique correctement


                def copier_cle_callback(key=publique, nom=nom):  # Utiliser les arguments par défaut
                    copier_cle(key, nom)


                # Passer à la ligne suivante après avoir traité le nom et la clé
                i += 2
            else:
                # Si la clé publique n'est pas trouvée, passer à la ligne suivante
                i += 1
        else:
            # Passer à la ligne suivante si la ligne ne commence pas par "Nom:"
            i += 1


def recherche_clepublique(event):
    with open("registre.txt", "r") as fichier:
        contenu = fichier.readlines()
        i = 0  # Utilisé pour suivre la position actuelle dans le contenu
        selected_name = combobox2.get()
        entry_noms_pu = []
        for ligne in contenu:
            if ligne.startswith("Nom: " + selected_name):
                nom = ligne.split(": ")[1].strip()
                entry_noms_pu.append(nom)
                key = contenu[i + 1].split(": ")[1].strip()  # Ligne suivante

                copier_cle_cocobox(key, nom)  # Remplacer "" par la clé publique que vous voulez utiliser

                # Passer à la ligne suivante après avoir traité le nom
                i += 1
            else:
                # Passer à la ligne suivante si la ligne ne commence pas par "Nom:"
                i += 1


def on_name_selected_menu2(event):
    selected_name = combobox2.get()
    copier_cle_callback()


combobox2 = ttk.Combobox(frame3, values=entry_noms_pu, width=60)
combobox2.grid(sticky="W", row=5, column=3, padx=10, pady=10)
combobox2.bind("<<ComboboxSelected>>", recherche_clepublique)

lighter_blue_hex = "#cee6ed"

label_destinataire4 = ttk.Label(frame, text="Certificates:", font=("Helvetica", 12))
label_destinataire4.grid(row=4, column=0, pady=10, sticky="W", padx=5)

label_destinataire4.grid_forget()
frame4.grid_forget()

frame2 = tk.Frame(fenetre)
frame2.grid(row=0, column=0, padx=10, pady=30, sticky="N")


class ButtonApp:
    def __init__(self, frame):

        from tkinter import ttk

        style = ttk.Style()

        style.configure('3boutton.TButton')

        self.image1 = PhotoImage(file='button_image1.png')
        self.image2 = PhotoImage(file='configuration.png')
        self.image3 = PhotoImage(file='private_key.png')

        self.button1 = ttk.Button(frame, image=self.image1, compound=LEFT, text="Notepad", width=10,
                                   command=self.toggle_button1)
        self.button1.grid(row=0, column=7, padx=1, sticky="S", ipady=11)
        self.button1.image = self.image1  # Gardez une référence à l'image
        self.button1.bind("<Enter>", lambda event, b=self.button1: b.config())
        self.button1.bind("<Leave>", lambda event, b=self.button1: self.on_leave(event, b))

        self.button2 = ttk.Button(frame, text="Configuration", image=self.image2, compound=LEFT, width=13,
                                  command=self.toggle_button2)
        self.button2.grid(row=0, column=8, sticky="S", ipady=11)
        self.button2.bind("<Enter>", lambda event, b=self.button2: b.config())
        self.button2.bind("<Leave>", lambda event, b=self.button2: self.on_leave(event, b))

        self.button3 = ttk.Button(frame, text="Private Keys", image=self.image3, compound=LEFT, width=12,
                                  command=self.toggle_button3)
        self.button3.grid(row=0, column=9, padx=1, sticky="S", ipady=11)
        self.button3.bind("<Enter>", lambda event, b=self.button3: b.config())
        self.button3.bind("<Leave>", lambda event, b=self.button3: self.on_leave(event, b))

        self.active_button = None
        self.toggle_button1()

    def toggle_button1(self):
        self.toggle_button(self.button1)
        frame3.grid_forget()
        label_destinataire.grid_forget()

        frame3.place_forget()
        frame4.grid_forget()
        frame4.place_forget()
        label_destinataire4.grid_forget()

        label_message.grid(row=4, column=0)
        champ_message.grid(row=2, column=0, sticky="news", padx=10)
        bouton_retour.grid(row=4, column=1, padx=15, sticky="news")

    def toggle_button2(self):
        label_message.grid_forget()
        champ_message.grid_forget()
        bouton_retour.grid_forget()
        frame4.grid_forget()
        frame4.place_forget()
        label_destinataire4.grid_forget()

        marge_horizontal = 20
        frame3.grid(row=2, column=0, sticky="NEWS", padx=marge_horizontal, pady=marge_horizontal)

        label_destinataire.grid(row=4, column=0)

        self.toggle_button(self.button2)

    def toggle_button3(self):
        label_message.grid_forget()
        champ_message.grid_forget()
        bouton_retour.grid_forget()
        frame3.grid_forget()
        label_destinataire.grid_forget()
        frame3.place_forget()

        self.toggle_button(self.button3)

        label_destinataire4.grid(row=4, column=0)
        marge_horizontal = 20
        frame4.grid(row=2, column=0, sticky="NSEW", padx=marge_horizontal, pady=marge_horizontal)

    def toggle_button(self, button):
        if self.active_button:
            self.active_button.config()
        if self.active_button == button:
            self.active_button = None
        else:
            button.config()
            self.active_button = button

    def on_leave(self, event, button):
        # Rétablir la couleur de fond lorsque la souris quitte le bouton
        if self.active_button != button:
            button.config()


def show_popup_menu(event):
    try:
        popup_menu.tk_popup(event.x_root, event.y_root, 0)
    finally:
        popup_menu.grab_release()


champ_message.bind("<Button-3>", show_popup_menu)

# Just simply import the azure.tcl file
fenetre.tk.call("source", "azure.tcl")


# Then set the theme you want with the set_theme procedure
fenetre.tk.call("set_theme", "dark")

def change_theme():
    # NOTE: The theme's real name is azure-<mode>
    if fenetre.tk.call("ttk::style", "theme", "use") == "azure-dark":
        # Set light theme
        fenetre.tk.call("set_theme", "light")
    else:
        # Set dark theme
        fenetre.tk.call("set_theme", "dark")

parameters_menu.add_command(label="Toggle light/dark theme", command=change_theme,
                            compound=LEFT)



toggle_key_visibility2()
toggle_key_visibility()
app = ButtonApp(frame)

fenetre.mainloop()